// CYBER AI call intelligence: shared by the browser (window.CallIntel) and the Node backend (require).
// Pure functions only: no network, no storage. Everything here is a rule-based estimate, never a verdict about a person.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CallIntel = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const CATEGORIES = {
    impersonation: 'Pretending to be police, a bank or a company',
    otp_or_password: 'Asked for an OTP, PIN or password',
    payment_demand: 'Demanded money or a payment',
    prize_or_lottery: 'Prize, lottery or reward claim',
    tech_support: 'Fake tech support or remote-access request',
    telemarketing: 'Unwanted sales or promotional call',
    robocall: 'Automated / recorded call',
    other: 'Other suspicious behaviour'
  };

  // ---------- number parsing (India-aware, generic international fallback) ----------
  function normalizeNumber(raw) {
    const input = String(raw == null ? '' : raw).trim();
    if (!input) return { valid: false, error: 'Enter a phone number.' };
    if (/[a-z]/i.test(input.replace(/^tel:/i, '').replace(/ext\.?\s*\d+$/i, ''))) return { valid: false, error: 'A phone number can only contain digits, spaces, + and dashes.' };
    let s = input.replace(/^tel:/i, '').replace(/[\s().-]/g, '');
    let plus = false;
    if (s.startsWith('+')) { plus = true; s = s.slice(1); } else if (s.startsWith('00')) { plus = true; s = s.slice(2); }
    if (!/^\d+$/.test(s)) return { valid: false, error: 'A phone number can only contain digits, spaces, + and dashes.' };
    if (s.length < 3) return { valid: false, error: 'That number is too short.' };
    if (s.length > 15) return { valid: false, error: 'That number is too long (maximum 15 digits).' };

    if (!plus) {
      if (s.length <= 6) return { valid: true, digits: s, e164: null, region: 'IN', cc: '', type: 'shortcode', key: 'S' + s, international: false };
      if (/^1800\d{7}$/.test(s) || /^1860\d{7}$/.test(s)) return { valid: true, digits: s, e164: null, region: 'IN', cc: '', type: 'tollfree', key: 'T' + s, international: false };
      if (/^0\d{10}$/.test(s) && /^0[6-9]/.test(s)) s = '91' + s.slice(1);          // 09876543210
      else if (/^[6-9]\d{9}$/.test(s)) s = '91' + s;                                // 9876543210
      else if (/^91[6-9]\d{9}$/.test(s)) { /* already has 91 */ }
      else if (/^0\d{9,10}$/.test(s)) s = '91' + s.slice(1);                        // landline with STD code
      else if (/^140\d{7}$/.test(s)) s = '91' + s;                                  // telemarketing series
      else if (/^160\d{7}$/.test(s)) s = '91' + s;                                  // service/transactional series
      else return { valid: false, error: 'Add the country code (for example +91 98765 43210) so the number can be understood.' };
    }
    if (s.length < 8) return { valid: false, error: 'That number is too short for an international number.' };
    const e164 = '+' + s;
    const out = { valid: true, digits: s, e164, key: e164, international: true, region: '??', cc: '', type: 'unknown' };
    if (s.startsWith('91')) {
      const n = s.slice(2); out.region = 'IN'; out.cc = '91'; out.international = false;
      if (n.length !== 10) return { valid: false, error: 'Indian numbers have 10 digits after +91.' };
      out.type = /^[6-9]/.test(n) ? 'mobile' : /^140/.test(n) ? 'telemarketing' : /^160/.test(n) ? 'service' : /^[2-5]/.test(n) ? 'landline' : 'unknown';
      out.national = n;
    } else {
      out.cc = s.startsWith('1') ? '1' : '';   // other country codes vary in length, so they are not guessed
      out.region = 'INTL';
      out.national = s.slice(out.cc.length);
    }
    return out;
  }

  function maskNumber(p) {
    if (!p || !p.valid) return '';
    const d = p.digits, tail = d.slice(-4);
    if (p.type === 'shortcode') return d;
    const head = p.international || p.cc ? (p.cc ? '+' + p.cc + ' ' : '+') : '';
    return head + '•'.repeat(Math.max(0, d.length - (p.cc ? p.cc.length : 0) - 4)) + tail;
  }

  // North American area codes outside the US/Canada that are commonly used in callback ("one ring") scams.
  const CARIBBEAN_NANP = ['242', '246', '264', '268', '284', '340', '345', '441', '473', '649', '664', '721', '758', '767', '784', '809', '829', '849', '868', '869', '876'];

  function hasRun(d) {           // 6 digits in a row going up or down by one (e.g. 123456, 987654)
    for (let i = 0; i + 6 <= d.length; i++) {
      let up = true, down = true;
      for (let j = 1; j < 6; j++) { const a = +d[i + j - 1], b = +d[i + j]; if (b !== a + 1) up = false; if (b !== a - 1) down = false; }
      if (up || down) return true;
    }
    return false;
  }
  function numberSignals(p) {
    const s = [];
    if (!p || !p.valid) return s;
    if (p.type === 'telemarketing') s.push({ text: 'Starts with 140, the number series used for telemarketing and promotional calls. Expect a sales call.', points: 15, source: 'pattern' });
    if (p.international) s.push({ text: 'International number' + (p.cc ? ' (+' + p.cc + ')' : '') + '. Unexpected calls from abroad are a common pattern in scam calls, but many are genuine.', points: 15, source: 'pattern' });
    if (p.cc === '1' && p.national && CARIBBEAN_NANP.includes(p.national.slice(0, 3))) s.push({ text: 'The +1 area code ' + p.national.slice(0, 3) + ' is outside the US and Canada. These codes are often used in "call back" scams.', points: 15, source: 'pattern' });
    if (/^(882|883|881|878)/.test(p.digits) && p.international) s.push({ text: 'International network prefix that is rarely used by ordinary callers.', points: 15, source: 'pattern' });
    if (p.type !== 'shortcode' && (/(\d)\1{5,}/.test(p.digits) || hasRun(p.digits))) s.push({ text: 'Unusual repeating or sequential digits.', points: 8, source: 'pattern' });
    return s;
  }

  // ---------- risk assessment from the three kinds of evidence ----------
  const levelOf = n => (n >= 70 ? 'High' : n >= 35 ? 'Medium' : 'Low');
  function topCategory(cats) {
    const e = Object.entries(cats || {}).sort((a, b) => b[1] - a[1])[0];
    return e ? (CATEGORIES[e[0]] || e[0]) : '';
  }
  // verified: {name, category, source} | null; community: {reports, categories} | null (null = not checked)
  function assess(p, verified, community) {
    const reasons = []; let score = 0;
    const n = community && community.reports ? community.reports : 0;
    if (n > 0) {
      score += n >= 10 ? 70 : n >= 5 ? 60 : n >= 3 ? 45 : 25;
      const top = topCategory(community.categories);
      reasons.push({ source: 'community', text: n + ' separate user report' + (n === 1 ? '' : 's') + ' flagged this number' + (top ? ', most often as: ' + top.toLowerCase() : '') + '. These are unverified reports from users.' });
    }
    let pat = 0;
    numberSignals(p).forEach(x => { pat += x.points; reasons.push({ source: 'pattern', text: x.text }); });
    score += Math.min(35, pat);
    if (verified) {
      reasons.unshift({ source: 'verified', text: 'Matches an official number in the verified list: ' + verified.name + '. Caller ID can be spoofed, so this is not proof that the caller is genuine.' });
      score = n >= 3 ? score : Math.min(score, 10);
    }
    score = Math.max(0, Math.min(100, Math.round(score)));
    const level = levelOf(score);
    if (!reasons.length) reasons.push({ source: 'pattern', text: 'No reports and no suspicious number pattern were found. This does not mean the caller is safe.' });
    const verdict = verified && n < 3 ? 'Listed official number' : level === 'High' ? 'High risk: several warning signs' : level === 'Medium' ? 'Be careful: possible spam or scam' : 'No clear warning signs';
    const REC = {
      High: ['Do not share OTPs, PINs, passwords or card details, and do not install any app they ask for.', 'Do not call back. Contact the organisation only through the number on its official website or app.', 'You can decline or block this number. If money was lost, call 1930 immediately.'],
      Medium: ['Do not share personal or banking details on this call.', 'Ask who is calling, then verify through the organisation\'s official contact details.', 'Hang up if they pressure you.'],
      Low: ['Stay careful with unexpected requests. Caller ID can be faked.', 'Never share OTPs, PINs or passwords on a call.']
    };
    let confidence = verified ? 0.9 : Math.min(0.85, 0.3 + n * 0.05 + (pat ? 0.1 : 0));
    return { risk_score: score, risk_level: level, verdict, reasons, recommendations: REC[level], confidence: Math.round(confidence * 100) / 100 };
  }

  // ---------- call transcript red flags ----------
  const FLAGS = [
    { id: 'impersonation', label: 'Possible impersonation',
      re: /\b(police|cbi|cid|narcotics|customs|income tax|enforcement directorate|cyber ?(?:crime|cell)|rbi|reserve bank|trai|telecom (?:department|authority)|bank (?:officer|manager|executive|representative)|government officer|inspector|judge|court order|courier|fedex|dhl|amazon|microsoft|tech(?:nical)? support|customer (?:care|support|service)|calling from (?:the )?\w+)\b/gi },
    { id: 'credentials', label: 'Asks for OTP, password or remote access',
      re: /\b(otp|one.?time (?:password|code|pin)|verification code|pin|upi pin|cvv|password|card number|expiry date|net ?banking|aadhaar number|pan number|share (?:the |your )?code|anydesk|teamviewer|quicksupport|screen ?shar\w*|remote access|install (?:an? |the )?app)\b/gi },
    { id: 'payment', label: 'Demands a payment',
      re: /\b(pay(?:ment)?|transfer|deposit|send (?:the )?money|upi|fine|penalty|challan|processing fee|registration fee|refund fee|gift card|bitcoin|crypto|safe account|verification amount|wire)\b/gi },
    { id: 'urgency', label: 'Urgency or pressure tactics',
      re: /\b(urgent(?:ly)?|immediately|right now|within \d+ ?(?:minutes?|hours?|hrs?)|last (?:chance|warning)|final notice|arrest(?:ed)?|warrant|legal action|case (?:is |has been )?registered|jail|digital arrest|blocked today|don'?t (?:tell|disconnect|hang up)|do not (?:tell|disconnect|hang up)|stay on the line|keep (?:this )?(?:a )?secret)\b/gi }
  ];
  function transcriptFindings(text) {
    const t = String(text || '');
    return FLAGS.map(f => {
      const seen = new Set(), ev = [];
      (t.match(f.re) || []).forEach(m => { const k = m.toLowerCase(); if (!seen.has(k) && ev.length < 4) { seen.add(k); ev.push(m.length > 40 ? m.slice(0, 40) : m); } });
      return { id: f.id, label: f.label, hit: ev.length > 0, evidence: ev };
    });
  }
  // Floor for the transcript score when several independent red flags appear together.
  function transcriptFloor(findings) {
    const n = findings.filter(f => f.hit).length;
    const combo = findings.find(f => f.id === 'credentials').hit && findings.find(f => f.id === 'impersonation').hit;
    return Math.max([0, 20, 50, 78, 90][n], combo ? 70 : 0);
  }

  return { CATEGORIES, normalizeNumber, maskNumber, numberSignals, assess, transcriptFindings, transcriptFloor, levelOf };
});
