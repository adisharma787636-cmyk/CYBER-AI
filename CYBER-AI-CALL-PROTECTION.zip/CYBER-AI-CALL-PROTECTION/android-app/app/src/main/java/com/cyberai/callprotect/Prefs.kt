package com.cyberai.callprotect

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** All on-device state. Nothing here is sent anywhere. History keeps only the last 4 digits of a number. */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("cyberai_prefs", Context.MODE_PRIVATE)

    // Consent: everything is OFF until the user explicitly agrees in the app.
    var agreed: Boolean
        get() = sp.getBoolean("agreed", false)
        set(v) { sp.edit().putBoolean("agreed", v).apply() }
    var identify: Boolean
        get() = sp.getBoolean("identify", false)
        set(v) { sp.edit().putBoolean("identify", v).apply() }
    var spam: Boolean
        get() = sp.getBoolean("spam", false)
        set(v) { sp.edit().putBoolean("spam", v).apply() }
    var share: Boolean
        get() = sp.getBoolean("share", false)
        set(v) { sp.edit().putBoolean("share", v).apply() }
    /** Off by default. When off the app only WARNS and never rejects a call by itself (except numbers you blocked). */
    var autoBlockHigh: Boolean
        get() = sp.getBoolean("autoBlockHigh", false)
        set(v) { sp.edit().putBoolean("autoBlockHigh", v).apply() }

    /** Protection is active only after consent AND at least one lookup option. */
    val protectionEnabled: Boolean get() = agreed && (identify || spam)

    var serverUrl: String
        get() = sp.getString("serverUrl", "") ?: ""
        set(v) { sp.edit().putString("serverUrl", v).apply() }

    /** Only https is accepted, so data is always encrypted in transit. Returns false if rejected. */
    fun saveServerUrl(raw: String): Boolean {
        val u = raw.trim().trimEnd('/')
        if (!u.startsWith("https://") || u.length < 12 || u.contains(" ")) return false
        serverUrl = u
        return true
    }

    fun revokeAll() {
        sp.edit().putBoolean("agreed", false).putBoolean("identify", false).putBoolean("spam", false).putBoolean("share", false).apply()
    }

    // ---- blocklist (numbers YOU chose to block, stored only on this phone) ----
    private fun digits(n: String) = n.filter { it.isDigit() }
    private fun key(n: String): String = digits(n).let { if (it.length > 10) it.takeLast(10) else it }
    fun isBlocked(n: String): Boolean = sp.getStringSet("blocked", emptySet())!!.contains(key(n))
    fun block(n: String) { val s = HashSet(sp.getStringSet("blocked", emptySet())!!); s.add(key(n)); sp.edit().putStringSet("blocked", s).apply() }
    fun clearBlocklist() = sp.edit().remove("blocked").apply()
    fun blockedCount(): Int = sp.getStringSet("blocked", emptySet())!!.size

    // ---- history (masked) ----
    fun mask(n: String): String { val d = digits(n); return if (d.length <= 4) d else "•".repeat(d.length - 4) + d.takeLast(4) }

    fun addHistory(maskedNumber: String, level: String, score: Int, note: String) {
        val arr = JSONArray(sp.getString("history", "[]"))
        val out = JSONArray()
        out.put(JSONObject().put("at", System.currentTimeMillis()).put("n", maskedNumber).put("l", level).put("s", score).put("note", note))
        for (i in 0 until minOf(arr.length(), 49)) out.put(arr.get(i))
        sp.edit().putString("history", out.toString()).apply()
    }

    fun history(): List<JSONObject> {
        val arr = JSONArray(sp.getString("history", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }

    fun clearHistory() = sp.edit().remove("history").apply()
}
