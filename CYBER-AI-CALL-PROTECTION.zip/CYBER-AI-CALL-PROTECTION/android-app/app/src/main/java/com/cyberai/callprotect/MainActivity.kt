package com.cyberai.callprotect

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

/**
 * Consent + settings screen. Built in code (no layout files, no libraries) to keep the project small.
 * The ONLY system permission flow used for call screening is Android's RoleManager dialog.
 */
class MainActivity : Activity() {
    private val navy = Color.parseColor("#0B1026")
    private val card = Color.parseColor("#1E2549")
    private val cyan = Color.parseColor("#00D9FF")
    private val muted = Color.parseColor("#929DBB")
    private val ok = Color.parseColor("#20C997")
    private val warn = Color.parseColor("#FFB547")
    private lateinit var prefs: Prefs
    private lateinit var root: LinearLayout
    private var resultView: TextView? = null

    private companion object { const val REQ_ROLE = 1; const val REQ_NOTIF = 2 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val sv = ScrollView(this).apply { setBackgroundColor(navy) }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(40)) }
        sv.addView(root)
        setContentView(sv)
        render()
    }

    override fun onResume() { super.onResume(); render() }

    // ---------------- small UI helpers ----------------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(t: String, size: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(4), 0, dp(4))
    }
    private fun box(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply { setColor(card); cornerRadius = dp(14).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    }
    private fun button(label: String, enabled: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        text = label; isEnabled = enabled; isAllCaps = false; setOnClickListener { onClick() }
    }
    private fun optBox(label: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) = CheckBox(this).apply {
        text = "$label\n$sub"; isChecked = on; setTextColor(Color.WHITE); textSize = 14f
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun roleHeld(): Boolean {
        val rm = getSystemService(RoleManager::class.java)
        return rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
    }

    // ---------------- screens ----------------
    private fun render() {
        root.removeAllViews()
        root.addView(text("CYBER AI", 28f, Color.WHITE, true))
        root.addView(text("Call Protection companion", 15f, cyan))
        root.addView(text("Experimental: not yet tested on a real phone by the developer. Please test it yourself before relying on it.", 12f, warn))
        statusCard()
        if (!prefs.agreed) consentCard() else { settingsCard(); testCard(); historyCard() }
        privacyCard()
    }

    private fun statusCard() {
        val active = roleHeld() && prefs.protectionEnabled
        val b = box()
        b.addView(text(if (active) "Protection is ON" else "Protection is OFF", 18f, if (active) ok else warn, true))
        b.addView(text(when {
            !prefs.agreed -> "Nothing is checked until you agree below."
            !roleHeld() -> "You agreed, but Android has not made CYBER AI your call-screening app yet. Tap the button in Settings below."
            else -> "Incoming calls are screened. By default you only get a warning; the call is never ended unless you blocked the number or switched on auto-block."
        }, 13f, muted))
        root.addView(b)
    }

    private fun consentCard() {
        val b = box()
        b.addView(text("Before you turn this on", 18f, Color.WHITE, true))
        b.addView(text(
            "What it can access: the incoming phone number that Android passes to the call-screening app you choose. " +
            "It does NOT read your contacts, messages, microphone or call audio, and it never records calls.\n\n" +
            "Why: to warn you about possible spam or scam calls before you answer.\n\n" +
            "How it is analysed: the number is sent over HTTPS to your CYBER AI server, which checks a verified list, anonymous user reports and number patterns. " +
            "If the server has an AI model, the model only receives derived features, never the number.\n\n" +
            "What is stored: on this phone, your choices, your blocklist and a history showing the last 4 digits only. On the server, only if you share reports, a salted hash of the number and a category.\n\n" +
            "How to turn it off: Disable protection in this app, or change your Caller ID & spam app in Android Settings.", 13f, muted))
        var identify = false; var spam = false; var share = false
        lateinit var agree: Button
        fun refresh() { agree.isEnabled = identify || spam }
        b.addView(optBox("Enable caller identification", "Show a name only when the number is in the verified list.", false) { identify = it; refresh() })
        b.addView(optBox("Enable spam-risk checking", "Send the number to the server to look up user reports.", false) { spam = it; refresh() })
        b.addView(optBox("Share anonymised reports", "Lets you report a number from the warning. Off unless you tick it.", false) { share = it })
        agree = button("Agree and choose CYBER AI in Android", false) {
            prefs.identify = identify; prefs.spam = spam; prefs.share = share; prefs.agreed = true
            afterAgree()
        }
        b.addView(agree)
        b.addView(text("Tick at least one of the first two options to continue. Agreeing here is separate from Android's own permission, which you confirm in the next system dialog.", 12f, muted))
        root.addView(b)
    }

    private fun afterAgree() {
        render()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)   // warnings are shown as notifications
        } else requestRole()
    }

    private fun requestRole() {
        val rm = getSystemService(RoleManager::class.java)
        when {
            !rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) -> toast("This phone does not support choosing a call-screening app.")
            rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) -> render()
            else -> startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), REQ_ROLE)   // Android's official dialog
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) {
            if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) toast("Without notification permission you will not see warnings.")
            requestRole()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ROLE) {
            toast(if (resultCode == RESULT_OK) "CYBER AI is now your call-screening app." else "Not enabled. You can try again from Settings.")
            render()
        }
    }

    private fun settingsCard() {
        val b = box()
        b.addView(text("Settings", 18f, Color.WHITE, true))
        val url = EditText(this).apply {
            hint = "https://your-server.example.com"; setText(prefs.serverUrl); setTextColor(Color.WHITE); setHintTextColor(muted)
            inputType = InputType.TYPE_TEXT_VARIATION_URI; textSize = 14f; isSingleLine = true
        }
        b.addView(text("Server address (https only)", 13f, muted)); b.addView(url)
        b.addView(button("Save server address") { if (prefs.saveServerUrl(url.text.toString())) toast("Saved.") else toast("Enter a full https:// address.") })
        b.addView(optBox("Caller identification", "Verified-list lookup.", prefs.identify) { prefs.identify = it })
        b.addView(optBox("Spam-risk checking", "Report lookup and risk score.", prefs.spam) { prefs.spam = it })
        b.addView(optBox("Share anonymised reports", "Adds a Report button to warnings.", prefs.share) { prefs.share = it })
        b.addView(optBox("Auto-block high-risk calls", "OFF by default. Only warns unless you turn this on. A wrong estimate could block a genuine call.", prefs.autoBlockHigh) { prefs.autoBlockHigh = it })
        if (!roleHeld()) b.addView(button("Choose CYBER AI as call-screening app") { requestRole() })
        b.addView(button("Disable protection") {
            prefs.revokeAll()
            toast("Consents removed. In the next screen choose another app (or none) as your Caller ID & spam app.")
            try { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) } catch (_: Exception) {}
            render()
        })
        root.addView(b)
    }

    private fun testCard() {
        val b = box()
        b.addView(text("Check a number", 18f, Color.WHITE, true))
        b.addView(text("Uses the same server lookup as live calls. Useful to test your server address.", 12f, muted))
        val num = EditText(this).apply { hint = "+91 98765 43210"; setTextColor(Color.WHITE); setHintTextColor(muted); inputType = InputType.TYPE_CLASS_PHONE }
        b.addView(num)
        val out = text("", 13f, Color.WHITE); resultView = out
        b.addView(button("Check number") {
            val n = num.text.toString().trim()
            if (n.isEmpty()) { out.text = "Enter a number."; return@button }
            if (!prefs.serverUrl.startsWith("https://")) { out.text = "Save an https server address first."; return@button }
            out.text = "Checking…"
            Thread {
                val msg = try {
                    val r = ApiClient(prefs).check(n, fast = false)
                    if (r == null) "No answer from the server. Check the address, your consents and your connection."
                    else "${r.level} risk (${r.score}): ${r.verdict}\n" +
                        (if (r.verifiedName != null) "VERIFIED: ${r.verifiedName}\n" else "Not in the verified list.\n") +
                        "User reports (unverified): ${r.reports}\n" +
                        r.reasons.joinToString("\n") { "• [${it.source}] ${it.text}" } +
                        "\n\nAutomated estimate, not a statement about any person."
                } catch (e: Exception) { "Could not reach the server: ${e.message}" }
                runOnUiThread { out.text = msg }
            }.start()
        })
        b.addView(out)
        root.addView(b)
    }

    private fun historyCard() {
        val b = box()
        b.addView(text("Recent suspicious calls", 18f, Color.WHITE, true))
        val h = prefs.history()
        if (h.isEmpty()) b.addView(text("None yet. Only medium or high-risk calls and blocked calls are saved, with the last 4 digits only.", 12f, muted))
        h.take(15).forEach {
            b.addView(text("${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(it.getLong("at")))}  ${it.getString("n")}  ${it.getString("l")} (${it.getInt("s")})", 13f))
        }
        b.addView(button("Delete call history") { prefs.clearHistory(); render() })
        b.addView(button("Clear my blocklist (${prefs.blockedCount()})") { prefs.clearBlocklist(); render() })
        root.addView(b)
    }

    private fun privacyCard() {
        val b = box()
        b.addView(text("Privacy promises built into this app", 15f, Color.WHITE, true))
        b.addView(text("• No call recording, no microphone, no contacts, no SMS.\n• Only HTTPS is allowed.\n• Calls are allowed by default; this app warns, it does not decide for you.\n• The AI is never given the phone number.", 12f, muted))
        root.addView(b)
    }
}
