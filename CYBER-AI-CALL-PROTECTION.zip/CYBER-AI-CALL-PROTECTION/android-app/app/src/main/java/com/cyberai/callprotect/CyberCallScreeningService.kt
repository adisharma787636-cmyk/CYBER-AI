package com.cyberai.callprotect

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telecom.Connection
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Android's supported call-screening hook. Android only calls this service after the user has chosen
 * CYBER AI as their "Caller ID & spam app" in the system dialog. We never see audio, contacts or messages.
 *
 * Default behaviour is to ALLOW every call and show a warning. A call is only rejected if
 *  (a) the number is on the blocklist the user built, or
 *  (b) the user switched on "auto-block high-risk calls" (off by default).
 */
class CyberCallScreeningService : CallScreeningService() {

    override fun onScreenCall(callDetails: Call.Details) {
        val allow = CallScreeningService.CallResponse.Builder().build()
        val answered = AtomicBoolean(false)
        fun respond(r: CallScreeningService.CallResponse) { if (answered.compareAndSet(false, true)) respondToCall(callDetails, r) }

        try {
            val prefs = Prefs(this)
            val number = callDetails.handle?.schemeSpecificPart
            if (callDetails.callDirection != Call.Details.DIRECTION_INCOMING || !prefs.protectionEnabled || number.isNullOrBlank()) {
                respond(allow); return
            }
            val reject = CallScreeningService.CallResponse.Builder().setDisallowCall(true).setRejectCall(true).build()
            if (prefs.isBlocked(number)) {
                prefs.addHistory(prefs.mask(number), "Blocked", 0, "On your blocklist")
                respond(reject); return
            }
            // Android waits only a few seconds, so do the lookup off the main thread with short timeouts.
            Thread {
                var response = allow
                try {
                    val r = ApiClient(prefs).check(number)
                    if (r != null && r.level != "Low") {
                        prefs.addHistory(prefs.mask(number), r.level, r.score, r.verdict)
                        Notifier.warn(this, r, carrierNote(callDetails))
                        if (prefs.autoBlockHigh && r.level == "High") response = reject
                    }
                } catch (_: Exception) {
                    // Any error (offline, timeout, bad reply): never block, just let the call through.
                } finally {
                    respond(response)
                }
            }.start()
        } catch (_: Exception) {
            respond(allow)
        }
    }

    /** Carrier-provided STIR/SHAKEN result, when Android supplies it (Android 11+). Shown as information only. */
    private fun carrierNote(d: Call.Details): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        return when (d.callerNumberVerificationStatus) {
            Connection.VERIFICATION_STATUS_FAILED -> "Your carrier could not verify this caller ID (it may be spoofed)."
            Connection.VERIFICATION_STATUS_PASSED -> "Your carrier verified this caller ID."
            else -> null
        }
    }
}
