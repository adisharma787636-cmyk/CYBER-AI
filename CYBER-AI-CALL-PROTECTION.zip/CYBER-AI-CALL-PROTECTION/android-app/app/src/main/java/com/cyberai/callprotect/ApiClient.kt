package com.cyberai.callprotect

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Reason(val text: String, val source: String)

/** What the server told us. verifiedName is only set for numbers in the server's VERIFIED list. */
data class CheckResult(
    val level: String, val score: Int, val verdict: String,
    val reasons: List<Reason>, val reports: Int, val verifiedName: String?, val number: String
)

/** Talks to the CYBER AI backend (/api/caller/check and /api/caller/report) over HTTPS only. */
class ApiClient(private val prefs: Prefs) {

    private fun post(path: String, body: JSONObject, connectMs: Int, readMs: Int): JSONObject? {
        val base = prefs.serverUrl
        if (!base.startsWith("https://")) return null          // never fall back to plain http
        val c = URL("$base/api$path").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = connectMs
            c.readTimeout = readMs
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: return null
            return if (c.responseCode in 200..299) JSONObject(text) else null
        } finally {
            c.disconnect()
        }
    }

    /** Sends the number only for the lookups the user agreed to. Returns null on any failure (the call is then simply allowed). */
    fun check(number: String, fast: Boolean = true): CheckResult? {
        if (!prefs.protectionEnabled) return null
        val body = JSONObject().put("number", number).put("identify", prefs.identify).put("spam", prefs.spam)
        // Android only waits a few seconds for a screening decision, so the live-call path uses short timeouts.
        val d = post("/caller/check", body, if (fast) 2000 else 8000, if (fast) 2500 else 12000) ?: return null
        val rs = d.optJSONArray("reasons")
        val reasons = (0 until (rs?.length() ?: 0)).map { val o = rs!!.getJSONObject(it); Reason(o.optString("text"), o.optString("source")) }
        val ver = d.optJSONObject("verified")?.optString("name")
        return CheckResult(
            d.optString("risk_level", "Low"), d.optInt("risk_score", 0), d.optString("verdict"),
            reasons, d.optJSONObject("community")?.optInt("reports", 0) ?: 0, ver, number
        )
    }

    /** Anonymised report. Only sent when the user ticked "share anonymised reports" and tapped Report. */
    fun report(number: String, category: String): Boolean {
        if (!prefs.agreed || !prefs.share) return false
        val body = JSONObject().put("number", number).put("category", category).put("consent", true)
        return post("/caller/report", body, 4000, 6000) != null
    }
}
