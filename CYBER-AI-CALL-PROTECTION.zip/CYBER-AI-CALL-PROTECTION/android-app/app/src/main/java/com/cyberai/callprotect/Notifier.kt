package com.cyberai.callprotect

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

/** Shows the scam-call warning. The user then answers, declines or blocks using Android's normal call screen. */
object Notifier {
    private const val CHANNEL = "call_warnings"
    const val ACTION_BLOCK = "com.cyberai.callprotect.BLOCK"
    const val ACTION_REPORT = "com.cyberai.callprotect.REPORT"
    const val EXTRA_NUMBER = "number"
    const val EXTRA_ID = "id"

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Call warnings", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun action(ctx: Context, act: String, number: String, id: Int, req: Int): PendingIntent {
        val i = Intent(ctx, NotificationActionReceiver::class.java).setAction(act).putExtra(EXTRA_NUMBER, number).putExtra(EXTRA_ID, id)
        return PendingIntent.getBroadcast(ctx, id * 10 + req, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun warn(ctx: Context, r: CheckResult, carrierNote: String?) {
        ensureChannel(ctx)
        val id = (r.number.hashCode() and 0x7fffffff) % 100000
        val lines = ArrayList<String>()
        if (r.verifiedName != null) lines.add("Verified list: ${r.verifiedName}")
        if (r.reports > 0) lines.add("${r.reports} user report(s), unverified")
        r.reasons.filter { it.source == "pattern" }.take(1).forEach { lines.add("Pattern: ${it.text}") }
        if (carrierNote != null) lines.add(carrierNote)
        lines.add("Automated estimate. Not proof about the caller.")
        val b = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("${r.level} risk call (${r.score}): ${r.verdict}")
            .setContentText(lines.first())
            .setStyle(Notification.BigTextStyle().bigText(lines.joinToString("\n")))
            .setCategory(Notification.CATEGORY_CALL)
            .setAutoCancel(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel), "Block number", action(ctx, ACTION_BLOCK, r.number, id, 1)).build())
        if (Prefs(ctx).share) b.addAction(Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_send), "Report as scam", action(ctx, ACTION_REPORT, r.number, id, 2)).build())
        ctx.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }

    fun cancel(ctx: Context, id: Int) = ctx.getSystemService(NotificationManager::class.java).cancel(id)
}
