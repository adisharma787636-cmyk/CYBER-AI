package com.cyberai.callprotect

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/** Handles the two buttons on the warning notification. Both are the user's own explicit choice. */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val number = intent.getStringExtra(Notifier.EXTRA_NUMBER) ?: return
        val id = intent.getIntExtra(Notifier.EXTRA_ID, 0)
        val prefs = Prefs(context)
        when (intent.action) {
            Notifier.ACTION_BLOCK -> {
                prefs.block(number)   // future calls from this number are rejected by CallScreeningService
                Toast.makeText(context, "Number blocked on this phone.", Toast.LENGTH_SHORT).show()
                Notifier.cancel(context, id)
            }
            Notifier.ACTION_REPORT -> {
                val pending = goAsync()
                Thread {
                    val ok = try { ApiClient(prefs).report(number, "other") } catch (_: Exception) { false }
                    android.os.Handler(context.mainLooper).post {
                        Toast.makeText(context, if (ok) "Anonymised report sent." else "Report not sent.", Toast.LENGTH_SHORT).show()
                    }
                    Notifier.cancel(context, id)
                    pending.finish()
                }.start()
            }
        }
    }
}
