plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cyberai.callprotect"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.cyberai.callprotect"
        minSdk = 29          // ROLE_CALL_SCREENING (RoleManager) needs Android 10+
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Deliberately no third-party libraries: only the Android framework, so there is nothing extra to audit.
dependencies { }
