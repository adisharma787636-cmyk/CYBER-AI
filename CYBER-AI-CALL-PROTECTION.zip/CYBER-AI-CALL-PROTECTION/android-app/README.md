# CYBER AI Call Protection (Android companion app)

A small Kotlin app that lets CYBER AI warn you about possible spam or scam calls **before you answer**.
A website cannot see phone calls, so this separate app uses Android's official **CallScreeningService** API.

> **Status: experimental. This code has NOT been compiled or tested on a real Android phone yet.**
> It was written carefully against the public Android APIs, but you must build it, run it on a real device
> and test it (steps below) before relying on it. Do not tell users live detection works until you have.

## What it does
- You read a consent screen, then tick optional boxes (all off by default): caller identification, spam-risk checking, share anonymised reports. Nothing is on until you agree.
- Android then shows **its own** system dialog ("Set CYBER AI as your Caller ID & spam app"). You confirm there. The app never bypasses this.
- For each incoming call, Android gives the app the caller number (and, on Android 11+, the carrier's caller-ID verification result). The app asks your CYBER AI server (`POST /api/caller/check`) and shows a warning notification for Medium and High risk numbers.
- The warning separates **Verified list**, **User reports (unverified)** and **Number pattern / automated estimate**.
- **Answer, ignore or block:** Android does not let a screening app pause a ringing call to ask a question. So the call keeps ringing normally: you answer or decline in your phone app as usual, and the notification offers **Block number** (blocks it on this phone) and **Report as scam** (only if you ticked sharing).
- By default calls are always **allowed**. Rejecting happens only for numbers you blocked, or if you turn on "Auto-block high-risk calls" (off by default, because an estimate can be wrong).

## What it does NOT do
No call recording, no microphone, no contacts, no SMS, no phone-state permission. Permissions are only `INTERNET` and `POST_NOTIFICATIONS`. No third-party libraries. Only `https://` servers are accepted.

## Build and run
1. Install **Android Studio** (Koala or newer) and open this `android-app` folder. Let it sync (it downloads Gradle 8.7 and the Android Gradle Plugin 8.5.2).
2. Start your backend somewhere reachable over **HTTPS** (for example your Netlify site; Netlify gives you HTTPS automatically). For local testing you can use an HTTPS tunnel such as `cloudflared` or `ngrok` pointing at `npm start`.
3. Plug in a real Android 10+ phone (USB debugging on) and press Run. The emulator can show the screens but is poor for real call testing.
4. In the app: read the consent screen, tick options, tap the button, confirm Android's dialog, then enter your server's https address and tap **Check number** to test the connection.

## Test checklist (do all of these on a real phone, then update this README)
- [ ] Consent screen: the button stays disabled until at least one of the first two boxes is ticked; nothing happens before you agree.
- [ ] Android's role dialog appears and, after you accept, the status card says Protection is ON.
- [ ] Check number `1930` shows **VERIFIED: National Cyber Crime Helpline**.
- [ ] Report a test number from another phone several times (use the website's report feature) and confirm a warning notification appears when it calls.
- [ ] Turn the server off: calls must still ring normally (fail-open).
- [ ] Hidden / private numbers ring normally with no crash.
- [ ] Block number from the notification, call again: the call is rejected.
- [ ] Disable protection, then check Android Settings > Apps > Default apps > Caller ID & spam app.
- [ ] Delete history and clear blocklist work.

## Limits you should know
- Android gives the screening app only a few seconds to answer, so lookups use short timeouts and fail open (the call is allowed).
- Hidden, private or withheld numbers have no number to look up.
- Some phone makers customise the dialer and may restrict background apps or notifications. Check battery and notification settings if warnings do not appear.
- Caller ID can be spoofed. A "verified list" match never proves who is calling.
- Publishing on Google Play needs a privacy policy and a review of the call-screening use. Build your own policy from the consent text.
