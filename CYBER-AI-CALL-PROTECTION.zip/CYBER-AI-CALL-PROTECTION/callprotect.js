// Call Protection page (website side), plus transcript-file upload for the Call Transcript page.
// A website can NOT see SIM calls. This page only (1) records the user's consent choices in this browser,
// (2) checks phone numbers the user types, and (3) explains the separate Android companion app (android-app/).
(function () {
  const CI = window.CallIntel;
  const $ = s => document.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const KEY = 'cyberai_callprot', HKEY = 'cyberai_callprot_history';
  const DEFAULTS = { enabled: false, identify: false, spam: false, share: false, at: null };
  const getS = () => { try { return Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch { return { ...DEFAULTS }; } };
  const setS = s => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch {} };
  const getH = () => { try { return JSON.parse(localStorage.getItem(HKEY) || '[]'); } catch { return []; } };
  const setH = h => { try { localStorage.setItem(HKEY, JSON.stringify(h.slice(0, 50))); } catch {} };
  const api = () => (window.API_BASE || '').replace(/\/$/, '') + '/api';
  let view = 'main', last = null;

  async function post(path, body) {
    let r;
    try { if (location.protocol === 'file:') throw new Error('file'); r = await fetch(api() + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); }
    catch { const e = new Error('The CYBER AI server is not connected.'); e.net = true; throw e; }
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(d.error || 'Request failed (' + r.status + ')'); e.status = r.status; throw e; }
    return d;
  }

  // ---------- consent screen ----------
  function consent() {
    $('#main').innerHTML = `<h1>Before you turn on Call Protection</h1><p class="sub">Read this first. Nothing is switched on until you press the agree button.</p>
    <div class="card pc-note-card"><b>Important:</b> agreeing here is <u>not</u> the same as Android permission. A website cannot see your phone calls, SIM, contacts or call log. Live call warnings only work through the separate Android companion app, which asks for Android's own permission.</div>
    <div class="grid" style="margin-top:16px">
      <div class="card"><h3>What can be accessed</h3><ul>
        <li><b>Website:</b> only the phone numbers you type into the number checker.</li>
        <li><b>Android app (optional):</b> the incoming number that Android gives to the call-screening app you choose. It does not read your contacts, messages or call audio.</li></ul></div>
      <div class="card"><h3>Why caller identification is needed</h3><p>To show a warning before you answer a call from an unknown number, and to show who a number belongs to when an official source confirms it.</p></div>
      <div class="card"><h3>How it is analysed</h3><p>Rules look at the number's pattern (country, type, repeated digits), a list of verified official numbers, and anonymous user reports. Results are labelled as <b>Verified</b>, <b>User reports</b> or <b>Automated estimate</b>, and never call a person a criminal.</p></div>
      <div class="card"><h3>Is anything sent to an AI service?</h3><p>If the server has an AI model connected, it receives only <b>derived features</b> (for example "international number, 3 reports"). It never receives the phone number. Call audio and transcripts are never part of caller checks.</p></div>
      <div class="card"><h3>What is stored</h3><ul>
        <li><b>On this device:</b> your choices, and a short history showing only the last 4 digits.</li>
        <li><b>On the server, only if you share reports:</b> a salted one-way hash of the number plus the category you chose. No raw number, no name, no audio.</li>
        <li>A number you check is sent to the server over a secure connection only for the lookup you agree to below.</li></ul></div>
      <div class="card"><h3>How to turn it off</h3><p>Use <b>Disable Protection</b> on this page at any time. It removes every consent. You can also delete your history here. For the Android app, change the call-screening app in your phone's Settings (Apps, Default apps, Caller ID &amp; spam app).</p></div>
    </div>
    <div class="card" style="margin-top:16px"><h3>Your choices (all optional, all off by default)</h3>
      <label class="pc-opt"><input type="checkbox" id="c_identify"><span>Enable caller identification<small>Looks the number up in the list of verified official numbers and shows who it is, only if verified.</small></span></label>
      <label class="pc-opt"><input type="checkbox" id="c_spam"><span>Enable spam-risk checking<small>Sends the number to the CYBER AI server to look for user reports and to calculate a risk score.</small></span></label>
      <label class="pc-opt"><input type="checkbox" id="c_share"><span>Share anonymised reports to improve detection<small>Lets you report a number as suspicious. Only a one-way hash of the number and your chosen category are stored.</small></span></label>
      <p class="note" id="c_msg">Choose at least one of the first two options to turn protection on.</p>
      <button class="btn" id="c_ok" disabled>Agree and enable protection</button> <button class="btn ghost" id="c_no" style="margin-left:8px">Cancel</button></div>`;
    const upd = () => { const ok = $('#c_identify').checked || $('#c_spam').checked; $('#c_ok').disabled = !ok; };
    ['#c_identify', '#c_spam', '#c_share'].forEach(id => $(id).onchange = upd);
    $('#c_no').onclick = () => { view = 'main'; render(); };
    $('#c_ok').onclick = () => {
      setS({ enabled: true, identify: $('#c_identify').checked, spam: $('#c_spam').checked, share: $('#c_share').checked, at: new Date().toISOString() });
      view = 'main'; render();
    };
  }

  // ---------- number checking ----------
  function localResult(p) {
    const a = CI.assess(p, null, null);
    return { type: 'caller', number: p.e164 || p.digits, masked: CI.maskNumber(p), region: p.region, number_type: p.type, verified: null, verified_checked: false, community: { checked: false }, ...a, ai: null, mode: 'local',
      limitations: 'Automated estimate based on number patterns only. It is not a statement about any person. Caller ID can be spoofed.' };
  }
  async function check() {
    const out = $('#pcOut'), btn = $('#pcGo'), raw = $('#pcNum').value;
    const p = CI.normalizeNumber(raw);
    if (!p.valid) { out.innerHTML = `<div class="err" role="alert">${esc(p.error)}</div>`; return; }
    const s = getS(), online = s.enabled && (s.identify || s.spam);
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span>Checking…'; out.innerHTML = '';
    let r, note = '';
    try {
      if (online) {
        try { r = await post('/caller/check', { number: p.e164 || p.digits, identify: s.identify, spam: s.spam }); }
        catch (e) { if (e.net || [404, 405, 501, 502, 503].includes(e.status)) { r = localResult(p); note = 'The server could not be reached, so only the on-device pattern check was done.'; } else throw e; }
      } else r = localResult(p);
      last = { r, p };
      out.innerHTML = resultHtml(r, note);
      if (s.enabled && r.risk_level !== 'Low') { const h = getH(); h.unshift({ at: new Date().toISOString(), masked: r.masked || CI.maskNumber(p), level: r.risk_level, score: r.risk_score, reports: (r.community && r.community.reports) || 0 }); setH(h); paintHistory(); }
      wireReport();
    } catch (e) { out.innerHTML = `<div class="err" role="alert">${esc(e.message)}</div>`; }
    btn.disabled = false; btn.textContent = 'Check number';
  }
  const SRC = { verified: 'Verified list', community: 'User reports', pattern: 'Number pattern' };
  function resultHtml(r, note) {
    const s = getS(), c = r.community || {}, cats = Object.entries(c.categories || {}).sort((a, b) => b[1] - a[1]);
    const ver = r.verified
      ? `<span class="pc-tag verified">Verified</span><b>${esc(r.verified.name)}</b><div class="note">${esc(r.verified.category)} · Source: ${esc(r.verified.source)}. Caller ID can be spoofed, so a match is not proof the caller is genuine.</div>`
      : `<span class="pc-tag none">Not verified</span>${r.verified_checked ? 'This number is not in the verified list. That does not mean it is unsafe.' : 'Not checked. Caller identification is off, or the server is not connected.'}`;
    const com = c.checked
      ? `<span class="pc-tag community">User-submitted</span><b>${c.reports} report${c.reports === 1 ? '' : 's'}</b>${cats.length ? '<div>' + cats.map(([k, n]) => `<span class="chip">${esc(CI.CATEGORIES[k] || k)} · ${n}</span>`).join('') + '</div>' : ''}<div class="note">Reports come from users and are not checked by CYBER AI. They are not proof of wrongdoing.</div>`
      : `<span class="pc-tag none">Not checked</span>Spam-risk checking is off, or the server is not connected.`;
    const all = r.reasons.map(x => `<li><span class="pc-tag ${x.source}">${esc(SRC[x.source] || x.source)}</span>${esc(x.text)}</li>`).join('');
    const ai = r.ai ? `<div class="pc-src ai"><span class="pc-tag ai">AI-generated</span><b>${esc(r.ai.risk_level)} risk (${r.ai.risk_score}) · ${esc(r.ai.verdict)}</b><ul>${r.ai.reasons.map(x => `<li>${esc(x)}</li>`).join('')}</ul><div class="note">An AI model's estimate from derived features only (it never saw the number). It can be wrong and does not change the score above.</div></div>` : '';
    const canReport = s.enabled && s.share && r.mode === 'online';
    const rep = canReport ? `<div class="pc-src"><b>Report this number</b><div class="note" style="margin:4px 0 10px">Only a one-way hash of the number and the category you pick are stored.</div><select id="pcCat" class="pc-select" aria-label="Report category">${Object.entries(CI.CATEGORIES).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}</select> <button class="btn ghost" id="pcRep" type="button" style="margin:0 0 0 8px">Submit anonymised report</button><div id="pcRepMsg" class="note" role="status"></div></div>`
      : `<p class="note">${s.enabled ? (s.share ? 'Reporting needs a connected server.' : 'To report a number, turn on “Share anonymised reports” in the settings above.') : 'Turn on Call Protection to save results and report numbers.'}</p>`;
    return `<div class="result" role="status"><div class="rhead"><div class="score ${r.risk_level}">${r.risk_score}</div>
      <div><div class="lvl ${r.risk_level}">${r.risk_level} risk · ${esc(r.verdict)}</div><div class="note" style="margin-top:4px">Number: ${esc(r.masked || '')} · ${r.mode === 'online' ? 'online lookup' : 'on-device pattern check'} · confidence ${Math.round(r.confidence * 100)}%</div></div></div>
      ${note ? `<div class="err" style="background:rgba(255,181,71,.12);color:#ffcf8a;border-color:rgba(255,181,71,.35)">${esc(note)}</div>` : ''}
      <div class="pc-src verified"><h3 style="font-size:15px;margin-bottom:6px">1 · Verified information</h3>${ver}</div>
      <div class="pc-src community"><h3 style="font-size:15px;margin-bottom:6px">2 · User-submitted reports</h3>${com}</div>
      <div class="pc-src"><h3 style="font-size:15px;margin-bottom:6px">3 · Why this score (automated estimate)</h3><ul class="pc-reasons">${all}</ul></div>
      ${ai}
      <h3>What to do</h3><ul>${r.recommendations.map(x => `<li>${esc(x)}</li>`).join('')}</ul>${rep}
      <p class="note">${esc(r.limitations)} A low score never means “safe”. Never share OTPs, PINs or passwords.</p></div>`;
  }
  function wireReport() {
    const b = $('#pcRep'); if (!b) return;
    b.onclick = async () => {
      const m = $('#pcRepMsg'); b.disabled = true; m.textContent = 'Sending…';
      try { const d = await post('/caller/report', { number: last.r.number, category: $('#pcCat').value, consent: true }); m.textContent = d.message; if (d.added) b.hidden = true; }
      catch (e) { m.textContent = e.message; b.disabled = false; }
    };
  }

  // ---------- history ----------
  function paintHistory() {
    const box = $('#pcHist'); if (!box) return; const h = getH();
    box.innerHTML = h.length ? `<div style="overflow-x:auto"><table><thead><tr><th>Time</th><th>Number</th><th>Risk</th><th>Reports</th></tr></thead><tbody>${h.map(x => `<tr><td>${esc(new Date(x.at).toLocaleString())}</td><td>${esc(x.masked)}</td><td class="lvl ${x.level}" style="border:0">${x.level} (${x.score})</td><td>${x.reports}</td></tr>`).join('')}</tbody></table></div><button class="btn ghost" id="pcDel" style="margin-top:12px">Delete caller history</button>`
      : '<div class="empty small">No suspicious callers saved yet. Medium and high-risk results are saved here (last 4 digits only) while protection is on.</div>';
    const d = $('#pcDel'); if (d) d.onclick = () => { if (confirm('Delete all caller history on this device?')) { setH([]); paintHistory(); } };
  }

  // ---------- main page ----------
  function main() {
    const s = getS(), on = s.enabled;
    const opt = (id, on_, title, sub) => `<label class="pc-opt"><input type="checkbox" id="${id}" ${on_ ? 'checked' : ''}><span>${title}<small>${sub}</small></span></label>`;
    $('#main').innerHTML = `<h1>Call Protection</h1><p class="sub">Check unknown numbers and understand scam-call risk. Guidance only: it never proves a caller is safe or guilty.</p>
    <div class="card pc-status"><span class="pc-dot ${on ? 'ok' : ''}" aria-hidden="true"></span>
      <div style="flex:1;min-width:220px"><b>${on ? 'Protection is ON' : 'Protection is OFF'}</b><div class="note" style="margin:2px 0 0">${on ? 'Your consent choices are saved in this browser. Live call warnings need the Android companion app (see below).' : 'Nothing is checked or saved until you agree on the next screen.'}</div></div>
      ${on ? '<button class="btn ghost" id="pcOff" style="margin:0">Disable Protection</button>' : '<button class="btn" id="pcOn" style="margin:0">Enable Call Protection</button>'}</div>
    ${on ? `<div class="card" style="margin-top:16px"><h3>Settings</h3>
      ${opt('s_identify', s.identify, 'Caller identification', 'Shows who a number is when it matches the verified list.')}
      ${opt('s_spam', s.spam, 'Spam-risk checking', 'Sends the number to the server to look up user reports.')}
      ${opt('s_share', s.share, 'Share anonymised reports', 'Lets you report numbers. Only a one-way hash and a category are stored.')}
      <p class="note" id="s_msg">${s.identify || s.spam ? '' : 'Both checks are off, so only the on-device pattern check runs.'}</p></div>` : ''}
    <div class="card" style="margin-top:16px"><h3>Check a phone number</h3>
      <p class="hint">${on && (s.identify || s.spam) ? 'Online lookup is on: the number is sent to your CYBER AI server for the checks you agreed to.' : 'Nothing leaves your device: only the built-in number pattern check runs.'}</p>
      <form id="pcForm" novalidate><label>Phone number<input type="text" id="pcNum" inputmode="tel" autocomplete="off" placeholder="+91 98765 43210"></label><button class="btn" id="pcGo" type="submit">Check number</button></form><div id="pcOut"></div></div>
    <div class="card" style="margin-top:16px"><h3>Recent suspicious callers</h3><div id="pcHist"></div></div>
    <div class="grid" style="margin-top:16px">
      <div class="card"><h3>Live call detection: Android companion app</h3><span class="pc-tag community">Experimental · not yet tested on a real phone</span>
        <p>Only a native Android app can see an incoming call. The companion app in the <code>android-app</code> folder uses Android's official call-screening service. It does not bypass any permission.</p>
        <ol><li>Build and install the app (see <code>android-app/README.md</code>).</li><li>Open it, read its consent screen and agree.</li><li>Android then shows its own system dialog: choose <b>CYBER AI</b> as your caller ID &amp; spam app.</li><li>Enter your server's <b>https</b> address in the app.</li></ol>
        <p class="note">By default it only warns you. Auto-blocking is a separate switch that is off unless you turn it on.</p></div>
      <div class="card"><h3>Call transcript analysis</h3><p>Paste a transcript or upload a text file to look for impersonation, OTP or password requests, payment demands and pressure tactics.</p><a class="btn" href="#call" style="display:inline-block;text-decoration:none">Open transcript analysis</a>
        <p class="note">Live audio transcription is a separate feature that is not included. CYBER AI never records calls or uploads call audio.</p></div>
    </div>`;
    paintHistory();
    const onBtn = $('#pcOn'); if (onBtn) onBtn.onclick = () => { view = 'consent'; render(); };
    const off = $('#pcOff'); if (off) off.onclick = () => { if (confirm('Disable Call Protection and remove all consents? Your history stays until you delete it.')) { setS({ ...DEFAULTS }); render(); } };
    ['identify', 'spam', 'share'].forEach(k => { const el = $('#s_' + k); if (el) el.onchange = () => { const n = getS(); n[k] = el.checked; setS(n); $('#s_msg').textContent = n.identify || n.spam ? 'Saved.' : 'Both checks are off, so only the on-device pattern check runs.'; const hint = document.querySelector('#pcForm').previousElementSibling; if (hint) hint.textContent = n.identify || n.spam ? 'Online lookup is on: the number is sent to your CYBER AI server for the checks you agreed to.' : 'Nothing leaves your device: only the built-in number pattern check runs.'; }; });
    $('#pcForm').onsubmit = e => { e.preventDefault(); check(); };
  }
  function render() { if (view === 'consent') consent(); else main(); window.scrollTo(0, 0); }
  window.callProtection = function () { view = 'main'; render(); };

  // ---------- Call Transcript page: file upload + live-audio note ----------
  const OK_EXT = /\.(txt|md|srt|vtt|csv|log)$/i, MAXF = 1024 * 1024, MAXC = 5000;
  function cleanTranscript(name, t) {
    if (/\.(srt|vtt)$/i.test(name)) t = t.split(/\r?\n/).filter(l => l.trim() && !/-->/.test(l) && !/^\d+$/.test(l.trim()) && !/^WEBVTT/i.test(l)).join('\n');
    return t.replace(/\u0000/g, '').trim();
  }
  window.enhanceCall = function () {
    const form = $('#form'), area = $('#f_text'); if (!form || !area) return;
    area.parentElement.insertAdjacentHTML('afterend', `<label>Or upload a transcript file (.txt, .md, .srt, .vtt, .csv, .log)<input type="file" id="callFile" accept=".txt,.md,.srt,.vtt,.csv,.log,text/plain"></label><p class="note" id="callFileMsg" style="margin-top:-6px"></p>
      <p class="note">Analysis checks for impersonation, requests for OTPs, passwords or remote access, payment demands and pressure tactics. The file is read on your device and only its text is analysed. CYBER AI never records calls. Live audio transcription is a separate feature and is not included.</p>`);
    $('#callFile').onchange = async e => {
      const f = e.target.files[0], msg = $('#callFileMsg'); if (!f) return; msg.className = 'note';
      if (!OK_EXT.test(f.name)) { msg.textContent = 'Only text transcripts are supported (.txt, .md, .srt, .vtt, .csv, .log). For audio, transcribe it first.'; e.target.value = ''; return; }
      if (f.size > MAXF) { msg.textContent = 'That file is larger than 1 MB.'; e.target.value = ''; return; }
      try {
        let t = cleanTranscript(f.name, await f.text());
        if (!t) { msg.textContent = 'The file is empty.'; return; }
        const cut = t.length > MAXC; if (cut) t = t.slice(0, MAXC);
        area.value = t; msg.className = 'note' + (cut ? ' warn' : ''); msg.textContent = cut ? 'Loaded. Only the first 5,000 characters are analysed.' : 'Loaded ' + t.length + ' characters. Review the text, then press Analyze.';
      } catch { msg.textContent = 'This file could not be read as text.'; }
    };
  };
})();
