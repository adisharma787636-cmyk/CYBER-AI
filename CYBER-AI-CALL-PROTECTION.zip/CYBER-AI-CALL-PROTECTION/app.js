const API = (window.API_BASE || '').replace(/\/$/, '') + '/api';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ico = d => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const MODS = {
  sms:   { name: 'SMS Scam Detection', short: 'Check a suspicious text message', icon: ico('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>'),
           fields: [{ id: 'text', label: 'Paste the SMS', type: 'area', ph: 'Example: Your bank account will be blocked today. Verify now at bit.ly/abc123' }] },
  url:   { name: 'URL Detection', short: 'Check a link before you open it', icon: ico('<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>'),
           fields: [{ id: 'url', label: 'Website address (URL)', type: 'line', ph: 'https://example.com/login' }] },
  email: { name: 'Email Detection', short: 'Check a suspicious email', icon: ico('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>'),
           fields: [{ id: 'sender', label: 'Sender (optional)', type: 'line', ph: 'support@bank-alert.com' }, { id: 'subject', label: 'Subject (optional)', type: 'line', ph: 'Urgent: verify your account' }, { id: 'text', label: 'Paste the email body', type: 'area', ph: 'Paste the full email text here' }] },
  image: { name: 'Deepfake Detection', short: 'Check if a photo is real or AI-made / edited', icon: ico('<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>'), file: true },
  call:  { name: 'Call Transcript Analysis', short: 'Check what a caller said', icon: ico('<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>'),
           fields: [{ id: 'text', label: 'Paste the call transcript', type: 'area', ph: 'Caller: This is the police. Your Aadhaar is linked to a crime. Share the OTP to avoid arrest…' }] }
};
const NAV = [['dashboard', 'Dashboard', ico('<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>')],
  ...Object.entries(MODS).map(([k, m]) => [k, m.name, m.icon]), ['report', 'Report a Scam', ico('<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><path d="M4 22v-7"/>')], ['history', 'History', ico('<path d="M3 3v5h5"/><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/><path d="M12 7v5l4 2"/>')]];

// ---- history (stored only in this browser) ----
const getH = () => { try { return JSON.parse(localStorage.getItem('cyberai_history') || '[]'); } catch { return []; } };
const addH = e => { try { localStorage.setItem('cyberai_history', JSON.stringify([e, ...getH()].slice(0, 200))); } catch {} if (typeof paintBell === 'function') paintBell(); };

async function call(path, opts) {
  let r; try { if (location.protocol === 'file:') throw new Error('file'); r = await fetch(API + path, opts); } catch { const e = new Error('The AI backend is not connected.'); e.net = true; throw e; }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(d.error || 'Request failed (' + r.status + ')'); e.status = r.status; throw e; }
  return d;
}

function findingsHtml(f) {
  return `<h3>Call red flags</h3><div>${f.map(x => `<span class="flag ${x.hit ? 'hit' : 'no'}" title="${x.hit ? 'Found in the transcript' : 'Not found in the transcript'}">${x.hit ? '⚠' : '✓'} ${esc(x.label)}${x.hit && x.evidence.length ? ': ' + x.evidence.map(e => '“' + esc(e) + '”').join(', ') : ''}</span>`).join('')}</div>`;
}
function resultHtml(r) {
  return `<div class="result" role="status">
    <div class="rhead"><div class="score ${r.risk_level}">${r.risk_score}</div>
      <div><div class="lvl ${r.risk_level}">${r.risk_level} risk · ${esc(r.verdict)}</div><div class="note">${r.source === 'local' ? 'Confidence' : 'AI confidence'} ${Math.round(r.confidence * 100)}% · ${r.source === 'local' ? 'checked by' : 'model'} ${esc(r.model)}</div></div></div>
    ${r.signals && r.signals.length ? `<h3>Technical signals</h3><div>${r.signals.map(s => `<span class="chip">${esc(s)}</span>`).join('')}</div>` : ''}
    ${r.findings ? findingsHtml(r.findings) : ''}
    <h3>Why</h3><ul>${r.reasons.map(x => `<li>${esc(x)}</li>`).join('') || '<li>No specific reasons given.</li>'}</ul>
    <h3>What to do</h3><ul>${r.recommendations.map(x => `<li>${esc(x)}</li>`).join('') || '<li>Verify the source independently.</li>'}</ul>
    <p class="note">${esc(r.limitations)} Never share OTPs, PINs or passwords.</p></div>`;
}

function analyzer(key) {
  const m = MODS[key];
  const fields = m.file ? `<label>Choose an image (JPG, PNG or WEBP)<input id="f_file" type="file" accept="image/jpeg,image/png,image/webp"></label><img id="prev" class="preview" alt="" hidden>`
    : m.fields.map(f => `<label>${esc(f.label)}${f.type === 'area' ? `<textarea id="f_${f.id}" rows="7" placeholder="${esc(f.ph)}"></textarea>` : `<input type="text" id="f_${f.id}" placeholder="${esc(f.ph)}">`}</label>`).join('');
  $('#main').innerHTML = `<h1>${esc(m.name)}</h1><p class="sub">${esc(m.short)}. The result is guidance, not a guarantee.</p>
    <div class="card"><form id="form" novalidate>${fields}<button class="btn" id="go" type="submit">Analyze</button></form><div id="out"></div></div>`;
  let img = null;
  if (m.file) $('#f_file').onchange = async e => {
    img = null; $('#prev').hidden = true; const f = e.target.files[0]; if (!f) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(f.type)) { $('#out').innerHTML = '<div class="err">Only JPG, PNG or WEBP images are allowed.</div>'; return; }
    if (f.size > 10 * 1024 * 1024) { $('#out').innerHTML = '<div class="err">Image is larger than 10 MB.</div>'; return; }
    const bmp = await createImageBitmap(f).catch(() => null);
    if (!bmp) { $('#out').innerHTML = '<div class="err">This file could not be read as an image.</div>'; return; }
    const sc = Math.min(1, 1024 / Math.max(bmp.width, bmp.height)), cv = document.createElement('canvas');
    cv.width = Math.round(bmp.width * sc); cv.height = Math.round(bmp.height * sc); cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
    const url = cv.toDataURL('image/jpeg', 0.85); img = { mediaType: 'image/jpeg', image: url.split(',')[1], name: f.name, file: f };
    $('#prev').src = url; $('#prev').hidden = false; $('#out').innerHTML = '';
  };
  $('#form').onsubmit = async e => {
    e.preventDefault(); const out = $('#out'), btn = $('#go');
    let body, preview;
    if (m.file) { if (!img) { out.innerHTML = '<div class="err">Choose an image first.</div>'; return; } body = { mediaType: img.mediaType, image: img.image }; preview = img.name; }
    else { body = {}; m.fields.forEach(f => body[f.id] = $('#f_' + f.id).value.trim()); const main = body.text ?? body.url; if (!main) { out.innerHTML = '<div class="err">Please fill in the main field first.</div>'; return; } preview = String(main).slice(0, 80); }
    btn.disabled = true; btn.innerHTML = '<span class="spin"></span>Analyzing…'; out.innerHTML = '';
    try {
      let r, dfErr;
      if (key === 'image' && window.deepfakeAnalyze) {
        try { r = await window.deepfakeAnalyze(img && img.file, msg => { btn.innerHTML = '<span class="spin"></span>' + esc(msg); }); } catch (e) { dfErr = e; }
      }
      if (!r) try { r = await call('/analyze/' + key, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); }
      catch (err) {
        if (key === 'image' && (err.net || [404, 405, 501, 502, 503].includes(err.status))) throw new Error('The deepfake model could not run' + (dfErr ? ' (' + dfErr.message + ')' : '') + '. Check your internet connection: the open-source model downloads once on first use, then it is cached.');
        if (err.net || [404, 405, 501, 502, 503].includes(err.status)) r = window.localAnalyze(key, body); else throw err;
      }
      out.innerHTML = resultHtml(r);
      addH({ at: new Date().toISOString(), type: key, preview, score: r.risk_score, level: r.risk_level, verdict: r.verdict });
    } catch (err) { out.innerHTML = `<div class="err" role="alert">${esc(err.message)}</div>`; }
    btn.disabled = false; btn.textContent = 'Analyze';
  };
}


function report() {
  $('#main').innerHTML = `<h1>Report a Scam</h1><p class="sub">This page only explains how to report. Cyber AI does not submit reports for you.</p>
  <div class="grid"><div class="card"><h3>Financial fraud: call 1930 right away</h3><p>If money was taken from your account or card, call the national cybercrime helpline <b>1930</b> as soon as possible. Acting within the first hours improves the chance of freezing the transfer. Tell your bank too.</p></div>
  <div class="card"><h3>National Cybercrime Reporting Portal</h3><p>File a complaint online at <a href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer">cybercrime.gov.in</a>. You can report financial fraud, social media crimes, and other online offences.</p></div></div>
  <div class="card" style="margin-bottom:16px"><h3>Before you report, keep this ready</h3><ul><li>Screenshots of the messages, emails, call logs and websites</li><li>The sender's number, email address or profile link</li><li>Transaction IDs, dates, amounts and bank or UPI details</li><li>Your own ID and contact details</li></ul><p class="note">Do not delete anything. Do not pay anyone who promises to recover your money for a fee.</p></div>
  <div class="card"><h3>Other useful steps</h3><ul><li>Block the sender and report the message as spam in your messaging app.</li><li>Fraud calls and SMS can also be reported on the Sanchar Saathi portal (<a href="https://sancharsaathi.gov.in" target="_blank" rel="noopener noreferrer">sancharsaathi.gov.in</a>).</li><li>Change passwords and enable two-step verification on any account you shared.</li><li>In an emergency, call 112.</li></ul><p class="note">Contact details can change. Confirm them on the official government websites.</p></div>`;
}

function history() {
  const h = getH();
  $('#main').innerHTML = `<h1>History</h1><p class="sub">Saved only in this browser. Only a short preview is kept, never the full message.</p>
  <div class="card">${h.length ? `<button class="btn ghost" id="clr" style="margin-bottom:12px">Clear history</button><div style="overflow-x:auto"><table><thead><tr><th>Time</th><th>Tool</th><th>Preview</th><th>Result</th></tr></thead><tbody>${h.map(x => `<tr><td>${esc(new Date(x.at).toLocaleString())}</td><td>${esc(MODS[x.type].name)}</td><td>${esc(x.preview)}</td><td class="lvl ${x.level}" style="border:0">${x.level} (${x.score})</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">No history yet.</div>'}</div>`;
  const c = $('#clr'); if (c) c.onclick = () => { if (confirm('Delete all history on this device?')) { localStorage.removeItem('cyberai_history'); history(); } };
}

function route() {
  const k = location.hash.slice(1) || 'dashboard';
  document.querySelectorAll('#nav a').forEach(a => a.classList.toggle('on', a.dataset.k === k));
  if (MODS[k]) { analyzer(k); if (window.enhanceShot) enhanceShot(k); if (k === 'call' && window.enhanceCall) window.enhanceCall(); } else if (k === 'protection' && window.callProtection) window.callProtection(); else if (k === 'report') report(); else if (k === 'settings') settings(); else if (k === 'history') history(); else dashboard();
  window.scrollTo(0, 0); document.body.classList.remove('open'); paintBell();
}
NAV.push(['settings', 'Settings', ico('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>')]);
NAV.push(['protection', 'Call Protection', ico('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9.5 9.5a2 2 0 0 1 2-.6l.8 1.7-.9.7a3.6 3.6 0 0 0 1.4 1.4l.7-.9 1.7.8a2 2 0 0 1-.6 2c-2.4.4-6.1-3.3-5.1-5.1z"/>')]);
const SECT = [['Menu', ['dashboard', 'sms', 'url', 'email', 'image', 'call', 'protection', 'history']], ['Support', ['report', 'settings']]];
$('#nav').innerHTML = SECT.map(([t, ks]) => `<div class="sect">${t}</div>` + ks.map(k => { const [, n, i] = NAV.find(x => x[0] === k); return `<a href="#${k}" data-k="${k}" title="${esc(n)}">${i}<span>${esc(n)}</span></a>`; }).join('')).join('');

const gname = () => { try { return localStorage.getItem('cyberai_name') || 'Guest'; } catch { return 'Guest'; } };
function paintUser() { const n = gname(); $('#uName').textContent = n; $('#avatar').textContent = n.split(/\s+/).map(w => w[0] || '').join('').slice(0, 2).toUpperCase() || 'G'; }
function paintBell() {
  const hi = getH().filter(x => x.level === 'High' && Date.now() - new Date(x.at) < 864e5), b = $('#badge');
  b.hidden = !hi.length; b.textContent = hi.length;
  $('#bellMenu').innerHTML = '<div class="mh">High-risk alerts (last 24 hours)</div>' + (hi.length ? hi.slice(0, 5).map(x => `<a href="#history"><b class="lvl High" style="border:0">High risk · ${x.score}</b><span>${esc(MODS[x.type].name)}: ${esc(x.preview.slice(0, 40))}</span></a>`).join('') : '<div class="empty small">No high-risk results in the last 24 hours.</div>');
}
function settings() {
  $('#main').innerHTML = `<h1>Settings</h1><p class="sub">Preferences are saved only in this browser.</p>
  <div class="card"><h3>Display name</h3><form id="nameForm"><label>Your name<input type="text" id="nameIn" maxlength="40" placeholder="Guest" value="${esc(gname() === 'Guest' ? '' : gname())}"></label><button class="btn" type="submit">Save name</button><span id="saved" class="note" style="margin-left:12px"></span></form></div>
  <div class="card" style="margin-top:16px"><h3>AI connection</h3><p id="aiState" class="muted">Checking…</p><p class="note">The AI model is set in the .env file or in Netlify environment variables. See README.</p></div>
  <div class="card" style="margin-top:16px"><h3>Data on this device</h3><p class="note">Scan history keeps only a short preview of each scan.</p><button class="btn ghost" id="wipe" type="button">Clear scan history</button></div>`;
  $('#nameForm').onsubmit = e => { e.preventDefault(); try { localStorage.setItem('cyberai_name', $('#nameIn').value.trim().slice(0, 40)); } catch {} paintUser(); $('#saved').textContent = 'Saved.'; };
  $('#wipe').onclick = clearHist;
  call('/health').then(d => { $('#aiState').textContent = d.llmConfigured ? 'AI online · model ' + d.model : 'Basic mode: the AI model is not configured.'; }).catch(() => { $('#aiState').textContent = 'Basic mode: the AI backend is not connected.'; });
}
function clearHist() { if (confirm('Delete all scan history on this device?')) { localStorage.removeItem('cyberai_history'); paintBell(); route(); } }
// top bar behaviour
const KEYS = { sms: ['sms', 'message', 'text'], url: ['url', 'link', 'website'], email: ['email', 'mail'], image: ['image', 'deepfake', 'photo'], call: ['call', 'transcript', 'phone'], protection: ['protection', 'caller', 'spam', 'number', 'block'], report: ['report', 'cybercrime', 'help', '1930'], history: ['history'], settings: ['settings', 'profile', 'name'], dashboard: ['dashboard', 'home'] };
$('#searchForm').onsubmit = e => {
  e.preventDefault(); const q = $('#search').value.trim().toLowerCase(); if (!q) return;
  const hit = Object.keys(KEYS).find(k => k.includes(q) || KEYS[k].some(w => w.includes(q) || q.includes(w)) || (MODS[k] && MODS[k].name.toLowerCase().includes(q)));
  if (hit) { location.hash = '#' + hit; $('#search').value = ''; $('#search').placeholder = 'Search pages and press Enter'; } else { $('#search').value = ''; $('#search').placeholder = 'No page found. Try “url” or “history”.'; }
};
$('#menuBtn').onclick = () => document.body.classList.toggle(innerWidth <= 860 ? 'open' : 'collapsed');
$('#scrim').onclick = () => document.body.classList.remove('open');
const menus = [['#bellBtn', '#bellMenu'], ['#userBtn', '#userMenu']];
menus.forEach(([b, m]) => { $(b).onclick = e => { e.stopPropagation(); const open = $(m).hidden; menus.forEach(([, mm]) => $(mm).hidden = true); $(m).hidden = !open; }; });
document.addEventListener('click', e => { if (!e.target.closest('.pop')) menus.forEach(([, m]) => $(m).hidden = true); else if (e.target.closest('.menu a')) menus.forEach(([, m]) => $(m).hidden = true); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') { menus.forEach(([, m]) => $(m).hidden = true); document.body.classList.remove('open'); } });
$('#uClear').onclick = () => { menus.forEach(([, m]) => $(m).hidden = true); clearHist(); };
paintUser();
window.addEventListener('hashchange', route); route();
call('/health').then(d => { const e = $('#health'); e.className = 'health ' + (d.llmConfigured ? 'ok' : ''); e.textContent = d.llmConfigured ? 'AI online · ' + d.model : 'Basic mode (AI not configured)'; })
  .catch(() => { const e = $('#health'); e.className = 'health'; e.textContent = 'Basic mode (AI not connected)'; });
