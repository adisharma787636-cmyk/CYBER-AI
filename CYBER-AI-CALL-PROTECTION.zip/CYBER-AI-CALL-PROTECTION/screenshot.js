// Screenshot upload for SMS, Email and URL pages.
// The image is read ON THE USER'S DEVICE with open-source tools (Tesseract.js OCR + jsQR for QR codes).
// It is never uploaded or stored. Only the (editable) extracted text goes through the normal analysis.
(function () {
  const TESS = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
  const JSQR = 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js';
  const OK_TYPES = ['image/jpeg', 'image/png', 'image/webp'], MAX = 10 * 1024 * 1024;
  const NOUN = { sms: 'message', email: 'email', url: 'link' };
  const loadScript = (src, ready) => new Promise((res, rej) => {
    if (ready()) return res();
    const s = document.createElement('script'); s.src = src; s.onload = () => res();
    s.onerror = () => rej(new Error('Could not load the reading tool. Check your internet connection (it downloads once, then the browser keeps it).'));
    document.head.appendChild(s);
  });

  // ---- text helpers ----
  const EMAIL_RE = /[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g;
  const URL_RE = /\b((?:https?:\/\/|www\.)[^\s<>"')\]]+|(?:[a-z0-9-]+\.)+(?:com|net|org|in|co|io|xyz|top|click|info|biz|link|me|app|site|online|live|shop|store|club|support|gov|edu|ly|gl|to|cc|tk|ml|ga|cf|gq|work|zip|page|dev|ru|cn)(?:\/[^\s<>"')\]]*)?)/gi;
  function findUrls(text) {
    const clean = text.replace(EMAIL_RE, ' '), out = [];
    (clean.match(URL_RE) || []).forEach(u => { u = u.replace(/[.,;:!?]+$/, ''); if (u.length > 3 && !out.includes(u)) out.push(u); });
    return out.slice(0, 10);
  }
  function parseEmail(text) {
    let sender = '', subject = ''; const body = [];
    text.split(/\r?\n/).map(l => l.trim()).filter(Boolean).forEach(l => {
      let m;
      if (!sender && (m = l.match(/^(?:from|sender)\s*[:\-]\s*(.+)$/i))) sender = m[1];
      else if (!subject && (m = l.match(/^subject\s*[:\-]\s*(.+)$/i))) subject = m[1];
      else if (!/^(to|date|sent|cc|bcc|reply-to)\s*:/i.test(l)) body.push(l);
    });
    if (!sender) { const e = text.match(EMAIL_RE); if (e) sender = e[0]; }
    return { sender, subject, body: body.join('\n') };
  }

  // ---- image reading ----
  async function toCanvas(file, maxSide, minWidth) {
    const bmp = await createImageBitmap(file).catch(() => null);
    if (!bmp) throw new Error('This file could not be opened as an image.');
    let sc = Math.min(1, maxSide / Math.max(bmp.width, bmp.height)); if (minWidth && bmp.width * sc < minWidth) sc = Math.min(2, minWidth / bmp.width);
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * sc); c.height = Math.round(bmp.height * sc);
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(bmp, 0, 0, c.width, c.height); return c;
  }
  async function readQr(file) {
    try {
      await loadScript(JSQR, () => window.jsQR);
      const c = await toCanvas(file, 1200), d = c.getContext('2d').getImageData(0, 0, c.width, c.height), q = window.jsQR(d.data, d.width, d.height);
      return q && q.data ? q.data : '';
    } catch { return ''; }
  }
  async function readText(file, onProgress) {
    await loadScript(TESS, () => window.Tesseract);
    const c = await toCanvas(file, 2400, 1000);
    const r = await window.Tesseract.recognize(c, 'eng', { logger: m => { if (m && m.status) onProgress(m.status, m.progress || 0); } });
    return { text: (r.data.text || '').trim(), conf: Math.round(r.data.confidence || 0) };
  }

  // ---- UI ----
  window.enhanceShot = function (key) {
    if (!['sms', 'email', 'url'].includes(key)) return;
    const $ = s => document.querySelector(s), card = $('#main .card'), form = $('#form'); if (!card || !form || $('#tabs')) return;
    const head = document.createElement('div');
    head.innerHTML = `<div class="tabs" id="tabs" role="tablist"><button type="button" class="tab on" data-t="paste" role="tab" aria-selected="true">Paste text</button><button type="button" class="tab" data-t="shot" role="tab" aria-selected="false">Upload screenshot</button></div>
      <p class="hint">Paste your suspicious ${NOUN[key]} or upload its screenshot. Our AI will analyse it for possible scams.</p>`;
    card.insertBefore(head, form);
    const fields = {
      sms: `<label>Extracted message (you can correct it)<textarea id="s_text" rows="6"></textarea></label>`,
      email: `<label>Sender<input type="text" id="s_sender"></label><label>Subject<input type="text" id="s_subject"></label><label>Email body (you can correct it)<textarea id="s_text" rows="7"></textarea></label><div id="s_urls"></div>`,
      url: `<div id="urlList"></div><label>Web address to analyse (you can correct it)<input type="text" id="s_url" placeholder="https://example.com/login"></label>`
    }[key];
    const panel = document.createElement('div'); panel.id = 'shotPanel'; panel.hidden = true;
    panel.innerHTML = `<div class="drop" id="drop" tabindex="0" role="button" aria-label="Upload a screenshot">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/></svg>
        <b>Drag and drop a screenshot here</b><span class="muted">or</span><label class="btn ghost" for="shotFile" style="margin:0">Browse files</label>
        <input id="shotFile" class="sr" type="file" accept="image/jpeg,image/png,image/webp">
        <small>JPG, PNG or WEBP, up to 10 MB. Your screenshot is read on your device and is never uploaded or stored.</small></div>
      <div id="shotView" hidden><img id="shotPrev" class="preview" alt="Uploaded screenshot preview"><button type="button" class="btn ghost" id="shotRemove">Remove image</button>
        <div class="progress" id="prog" hidden><div class="pbar"><i id="pfill"></i></div><span id="ptxt"></span></div>
        <div id="shotMsg" aria-live="polite"></div>
        <div id="shotFields" hidden>${fields}<button type="button" class="btn" id="shotGo">Analyse extracted ${NOUN[key]}</button></div></div>`;
    card.insertBefore(panel, $('#out'));

    const setTab = t => { const shot = t === 'shot'; form.hidden = shot; panel.hidden = !shot; $('#out').innerHTML = '';
      document.querySelectorAll('#tabs .tab').forEach(b => { const on = b.dataset.t === t; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); }); };
    document.querySelectorAll('#tabs .tab').forEach(b => b.onclick = () => setTab(b.dataset.t));

    let token = 0, prevUrl = '', ocrConf = null, viaQr = false;
    const msg = (t, cls) => { $('#shotMsg').innerHTML = t ? `<div class="${cls || 'err'}" role="alert">${esc(t)}</div>` : ''; };
    function reset() { token++; if (prevUrl) URL.revokeObjectURL(prevUrl); prevUrl = ''; $('#shotView').hidden = true; $('#drop').hidden = false; $('#shotFields').hidden = true; $('#prog').hidden = true; $('#shotFile').value = ''; msg(''); $('#out').innerHTML = ''; ocrConf = null; viaQr = false; }
    $('#shotRemove').onclick = reset;
    const drop = $('#drop'); drop.onclick = e => { if (!e.target.closest('label,input')) $('#shotFile').click(); };
    drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('#shotFile').click(); } };
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f) handle(f); });
    $('#shotFile').onchange = e => { const f = e.target.files[0]; if (f) handle(f); };

    async function handle(f) {
      reset(); const my = token;
      const fail = t => { $('#shotView').hidden = true; $('#drop').hidden = false; $('#shotMsg').innerHTML = ''; $('#out').innerHTML = `<div class="err" role="alert">${esc(t)}</div>`; };
      if (!f.size) return fail('That file is empty. Choose a screenshot.');
      if (!OK_TYPES.includes(f.type)) return fail('Only JPG, PNG or WEBP images are allowed.');
      if (f.size > MAX) return fail('That image is larger than 10 MB. Choose a smaller screenshot.');
      prevUrl = URL.createObjectURL(f); $('#shotPrev').src = prevUrl; $('#drop').hidden = true; $('#shotView').hidden = false; $('#prog').hidden = false;
      const prog = (txt, p) => { $('#ptxt').textContent = txt; $('#pfill').style.width = Math.round(p * 100) + '%'; };
      try {
        let qr = ''; if (key === 'url') { prog('Looking for a QR code…', .05); qr = await readQr(f); }
        prog('Preparing the reader (the first time it downloads about 10 MB)…', .1);
        let res = { text: '', conf: 0 }, ocrErr = null;
        try { res = await readText(f, (s, p) => { if (my !== token) return; prog(s === 'recognizing text' ? 'Reading the text in your screenshot…' : 'Preparing the reader…', s === 'recognizing text' ? .2 + p * .8 : p * .2); }); } catch (e) { ocrErr = e; }
        if (my !== token) return;
        if (ocrErr && !qr) throw ocrErr;
        $('#prog').hidden = true; ocrConf = res.text ? res.conf : null; viaQr = !!qr;
        if (!res.text && !qr) { msg('We could not read any text in this image. Try a clearer, larger screenshot, or use the Paste text tab.'); return; }
        fillFields(res.text, qr); $('#shotFields').hidden = false;
        if (res.text && res.conf < 60) msg('The text in this screenshot was hard to read (' + res.conf + '% clear). Please check it carefully and fix any mistakes before analysing.', 'note warn');
        else if (res.text) msg('Text read from your screenshot (' + res.conf + '% clear). Check it and fix any mistakes, then analyse.', 'note');
      } catch (e) { if (my === token) { $('#prog').hidden = true; msg('Could not read the screenshot: ' + (e.message || 'unknown error') + ' You can try again or use the Paste text tab.'); } }
    }

    function fillFields(text, qr) {
      if (key === 'sms') $('#s_text').value = text;
      if (key === 'email') {
        const p = parseEmail(text); $('#s_sender').value = p.sender; $('#s_subject').value = p.subject; $('#s_text').value = p.body;
        const us = findUrls(text); $('#s_urls').innerHTML = us.length ? `<p class="note" style="margin-top:0">Web addresses found in this email (shown as plain text, never opened):</p><div>${us.map(u => `<span class="chip">${esc(u)}</span>`).join('')}</div>` : '';
      }
      if (key === 'url') {
        const items = []; if (qr) items.push({ u: qr, tag: 'QR code' });
        findUrls(text).forEach(u => { if (!items.some(i => i.u === u)) items.push({ u, tag: 'Text' }); });
        $('#urlList').innerHTML = items.length ? `<p class="note" style="margin-top:0">${items.length > 1 ? 'Several web addresses were found. Choose the one to analyse (they are shown as text and never opened):' : 'Web address found (shown as text, never opened):'}</p>` +
          items.map((i, n) => `<label class="urlopt"><input type="radio" name="pick" value="${n}"${n === 0 ? ' checked' : ''}><span>${esc(i.u)}</span><em>${i.tag}</em></label>`).join('') : '<p class="note" style="margin-top:0">No web address was found in this screenshot. You can type or paste one below.</p>';
        $('#s_url').value = items[0] ? items[0].u : '';
        document.querySelectorAll('#urlList input').forEach(r => r.onchange = () => { $('#s_url').value = items[+r.value].u; });
        if (qr && !/^(https?:\/\/|www\.)/i.test(qr)) $('#urlList').insertAdjacentHTML('afterbegin', '<p class="note warn">The QR code does not contain a normal web link. Check the text carefully.</p>');
      }
    }

    $('#shotGo').onclick = () => {
      const go = $('#shotGo'), out = $('#out');
      const set = (id, v) => { $('#f_' + id).value = v; };
      if (key === 'sms') { if (!$('#s_text').value.trim()) { out.innerHTML = '<div class="err">The message box is empty. Type or correct the message first.</div>'; return; } set('text', $('#s_text').value); }
      if (key === 'email') { if (!$('#s_text').value.trim()) { out.innerHTML = '<div class="err">The email body is empty. Type or correct it first.</div>'; return; } set('sender', $('#s_sender').value); set('subject', $('#s_subject').value); set('text', $('#s_text').value); }
      if (key === 'url') { if (!$('#s_url').value.trim()) { out.innerHTML = '<div class="err">Enter or choose a web address first.</div>'; return; } set('url', $('#s_url').value); }
      go.disabled = true; go.innerHTML = '<span class="spin"></span>Analysing…'; form.requestSubmit();
      const t = setInterval(() => {
        if ($('#go').disabled) return; clearInterval(t); go.disabled = false; go.textContent = 'Analyse extracted ' + NOUN[key];
        if (out.querySelector('.result')) {
          const how = viaQr && ocrConf === null ? 'from a QR code' : 'from a screenshot';
          out.querySelector('.result').insertAdjacentHTML('beforeend', `<div class="ocrnote"><b>About this result</b><ul><li>Content read ${how}${ocrConf !== null ? ': text clarity ' + ocrConf + '%. This only shows how clearly the text could be read.' : '.'}</li><li>The risk score and confidence above come from the scam analysis of that text.</li><li>Neither is a security verification. ${key === 'url' ? 'The link was not opened, and no sign of danger does not mean it is safe.' : 'Never share OTPs, PINs or passwords.'}</li></ul></div>`);
        }
      }, 120);
    };
  };
})();
