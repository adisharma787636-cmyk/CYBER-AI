// Built-in basic checks. Used only when the AI backend is not connected. Clearly labelled in the result.
(function () {
  const COMMON = [
    [/(https?:\/\/|www\.)\S+/i, 15, 'Contains a link'],
    [/(bit\.ly|tinyurl|cutt\.ly|rb\.gy|is\.gd|t\.co)\b/i, 20, 'Uses a link shortener that hides the real destination'],
    [/(urgent|immediately|within \d+ ?(hours|hrs|minutes)|final notice|last warning|expires|act now|today only)/i, 15, 'Pressures you to act fast'],
    [/(\botp\b|one.?time (password|code)|verification code|\bpin\b|\bcvv\b|password)/i, 25, 'Asks for or mentions a secret code or password'],
    [/(kyc|account.{0,30}(blocked|suspended|locked|closed)|verify your (account|identity)|update your (bank|details|pan|aadhaar))/i, 20, 'Claims your account has a problem'],
    [/(you (have )?won|winner|prize|lottery|reward points|cashback|gift card|free gift)/i, 20, 'Offers a prize or reward'],
    [/(pay|transfer|send money|\bupi\b|bitcoin|crypto|processing fee|registration fee|refund fee)/i, 15, 'Mentions a payment or transfer'],
    [/(police|\bcbi\b|customs|income tax|\brbi\b|courier|fedex|dhl|aadhaar|\btrai\b|bank officer|support team)/i, 10, 'Names an authority or company that scammers often impersonate'],
    [/(don'?t tell|do not tell|keep (this )?(a )?secret|stay on the line)/i, 15, 'Asks you to keep it secret']
  ];
  const EXTRA = {
    email: [[/(attachment|attached|\.exe\b|\.zip\b|\.scr\b|\.docm\b|\.html?\b)/i, 15, 'Mentions an attachment that could be risky'], [/(dear (customer|user|account holder)|valued customer)/i, 10, 'Generic greeting instead of your name']],
    call: [[/(arrest|legal action|warrant|case (is )?registered|jail|fir\b)/i, 30, 'Threatens arrest or legal action'], [/(anydesk|teamviewer|quicksupport|screen ?share|install (an )?app)/i, 30, 'Asks you to install an app or share your screen']]
  };
  const REC = {
    High: ['Do not click links, call back unknown numbers, or share any codes.', 'Contact the company only through its official app or website.', 'If money was lost, call 1930 immediately.'],
    Medium: ['Do not act on this until you verify it independently.', 'Contact the organization on its official number.'],
    Low: ['No clear warning signs were found by basic rules, but this does not prove it is safe.', 'Stay careful with unexpected requests.']
  };
  function urlSignals(raw) {
    let u; try { u = new URL(/^[a-z]+:\/\//i.test(raw) ? raw : 'http://' + raw); } catch { return null; }
    if (!/^https?:$/.test(u.protocol)) return null;
    const s = [], h = u.hostname.toLowerCase(), p = h.split('.');
    if (u.protocol === 'http:') s.push('Uses http, not https');
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) s.push('Host is a raw IP address');
    if (h.includes('xn--')) s.push('Punycode domain (may imitate another site with look-alike characters)');
    if (p.length > 4) s.push('Many subdomains (' + p.length + ' levels)');
    if (u.username || raw.includes('@')) s.push('Contains @ or credentials in the URL');
    if (raw.length > 100) s.push('Very long URL');
    if (/\.(zip|top|xyz|click|work|country|gq|tk|ml|cf|ga|loan|support)$/.test(h)) s.push('Top-level domain often abused for scams');
    if (/(bit\.ly|tinyurl|cutt\.ly|rb\.gy|is\.gd|t\.co)$/.test(h)) s.push('Link shortener hides the real destination');
    if (/(login|verify|secure|update|account|bank|kyc|wallet|refund|reward)/.test(h)) s.push('Sensitive keyword inside the domain name');
    if ((h.match(/-/g) || []).length >= 3) s.push('Many hyphens in the domain');
    return s;
  }
  window.localAnalyze = function (type, b) {
    let score = 0, reasons = [], extra = {};
    if (type === 'url') {
      const s = urlSignals(b.url || ''); if (!s) throw new Error('Enter a valid http or https URL.');
      score = Math.min(100, s.length * 18); reasons = s.length ? s.slice() : ['No obvious warning patterns in the address itself'];
      reasons.push('Basic check only: the website itself was not visited'); extra = { signals: s };
    } else {
      const text = [b.sender, b.subject, b.text].filter(Boolean).join('\n');
      if (!String(b.text || '').trim()) throw new Error('Paste some text to analyze.');
      [...COMMON, ...(EXTRA[type] || [])].forEach(([re, pts, why]) => { if (re.test(text)) { score += pts; reasons.push(why); } });
      if (/(\botp\b|one.?time (password|code)|verification code|\bpin\b|\bcvv\b|password)/i.test(text) && /(https?:\/\/|www\.|bit\.ly|tinyurl|cutt\.ly|rb\.gy|is\.gd|kyc|account.{0,30}(blocked|suspended|locked|closed))/i.test(text)) { score += 15; reasons.push('Asks for a secret code together with a link or an account warning (a classic scam combination)'); }
      if (type === 'call' && window.CallIntel) {
        const f = window.CallIntel.transcriptFindings(text); extra.findings = f;
        f.filter(x => x.hit).forEach(x => reasons.push(x.label + ': ' + x.evidence.map(e => '“' + e + '”').join(', ')));
        const floor = window.CallIntel.transcriptFloor(f); if (floor > score) { score = floor; reasons.push('Several independent call red flags appear together.'); }
      }
      score = Math.min(100, score); if (!reasons.length) reasons = ['No common scam patterns found'];
    }
    const level = score >= 70 ? 'High' : score >= 35 ? 'Medium' : 'Low';
    return { type, risk_score: score, risk_level: level, verdict: level === 'High' ? 'Likely scam' : level === 'Medium' ? 'Suspicious' : 'No clear warning signs',
      reasons, recommendations: REC[level], confidence: 0.4, model: 'built-in rules (no AI)', source: 'local',
      limitations: 'Basic keyword and pattern check. It cannot understand context. A low score does not prove something is safe.', ...extra };
  };
})();
