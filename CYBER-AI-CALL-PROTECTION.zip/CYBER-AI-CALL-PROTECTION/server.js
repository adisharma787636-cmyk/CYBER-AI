// Local server: serves public/ and runs the same function Netlify runs.
const express = require('express'), fs = require('fs'), path = require('path');
try { fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n').forEach(l => { const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/); if (m && !process.env[m[1]]) process.env[m[1]] = m[2]; }); } catch {}
process.env.REPORT_STORE_FILE = process.env.REPORT_STORE_FILE || path.join(__dirname, 'data', 'reports.json');
const { handler } = require('./netlify/functions/api.js');
const app = express();
app.use(express.json({ limit: '8mb' }));
// Never serve server code, config, the report store or the Android project over HTTP.
app.use((req, res, next) => /^\/(data\/reports|netlify|android-app|node_modules)|^\/(server|test)\.js$|^\/package(-lock)?\.json$|^\/\.env/i.test(req.path) ? res.status(404).end() : next());
app.use(express.static(__dirname, { dotfiles: 'deny' }));
app.all('/api/*', async (req, res) => {
  const out = await handler({ path: req.path, httpMethod: req.method, headers: req.headers, body: JSON.stringify(req.body || {}) });
  res.status(out.statusCode).set(out.headers).send(out.body);
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`CYBER AI running at http://localhost:${port}`));
