// Decorative background only: drifting network, soft cursor glow, light trail. Never touches page logic.
(function () {
  var c = document.getElementById('fx'); if (!c || !c.getContext) return;
  var ctx = c.getContext('2d'), dpr = Math.min(window.devicePixelRatio || 1, 2), W = 0, H = 0;
  var fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  var still = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var nodes = [], trail = [], m = { x: -999, y: -999, tx: -999, ty: -999, on: false }, raf = 0;

  function resize() {
    W = innerWidth; H = innerHeight; c.width = W * dpr; c.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var n = Math.round(Math.min(70, W * H / 22000)); if (!fine) n = Math.round(n * 0.6);
    nodes = []; for (var i = 0; i < n; i++) nodes.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .25, vy: (Math.random() - .5) * .25, r: 1 + Math.random() * 1.2 });
    if (still) draw(0);
  }

  function draw(now) {
    ctx.clearRect(0, 0, W, H);
    if (fine && m.on) {
      var g = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, 280);
      g.addColorStop(0, 'rgba(53,107,255,.22)'); g.addColorStop(.45, 'rgba(0,217,255,.07)'); g.addColorStop(1, 'rgba(0,217,255,0)');
      ctx.fillStyle = g; ctx.fillRect(m.x - 280, m.y - 280, 560, 560);
    }
    var i, j, a, b, d;
    for (i = 0; i < nodes.length; i++) {
      a = nodes[i];
      if (!still) { a.x += a.vx; a.y += a.vy; if (a.x < 0) a.x = W; else if (a.x > W) a.x = 0; if (a.y < 0) a.y = H; else if (a.y > H) a.y = 0; }
      for (j = i + 1; j < nodes.length; j++) {
        b = nodes[j]; d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 140) { ctx.strokeStyle = 'rgba(80,120,255,' + (0.16 * (1 - d / 140)).toFixed(3) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
      }
      var near = fine && m.on ? Math.hypot(a.x - m.x, a.y - m.y) : 999;
      if (near < 190) { ctx.strokeStyle = 'rgba(0,217,255,' + (0.45 * (1 - near / 190)).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(m.x, m.y); ctx.stroke(); }
      ctx.fillStyle = near < 190 ? 'rgba(90,210,255,.85)' : 'rgba(120,160,255,.5)'; ctx.beginPath(); ctx.arc(a.x, a.y, a.r, 0, 6.283); ctx.fill();
    }
    if (fine && m.on && !still) {
      m.x += (m.tx - m.x) * .16; m.y += (m.ty - m.y) * .16;
      var last = trail[trail.length - 1];
      if (!last || Math.hypot(last.x - m.x, last.y - m.y) > 2) trail.push({ x: m.x, y: m.y, t: now });
    }
    while (trail.length && now - trail[0].t > 650) trail.shift();
    ctx.lineCap = 'round';
    for (i = 1; i < trail.length; i++) {
      var life = 1 - (now - trail[i].t) / 650; if (life <= 0) continue;
      ctx.strokeStyle = 'rgba(0,217,255,' + (life * .6).toFixed(3) + ')'; ctx.lineWidth = 1 + life * 3;
      ctx.beginPath(); ctx.moveTo(trail[i - 1].x, trail[i - 1].y); ctx.lineTo(trail[i].x, trail[i].y); ctx.stroke();
    }
  }
  function loop(now) { draw(now); raf = requestAnimationFrame(loop); }
  function start() { if (!still && !raf) raf = requestAnimationFrame(loop); }
  function stop() { if (raf) cancelAnimationFrame(raf); raf = 0; }

  addEventListener('resize', resize);
  document.addEventListener('visibilitychange', function () { document.hidden ? stop() : start(); });
  if (fine) {
    document.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      if (!m.on) { m.x = e.clientX; m.y = e.clientY; }
      m.tx = e.clientX; m.ty = e.clientY; m.on = true;
      var t = e.target.closest && e.target.closest('.card,.tool');
      if (t) { var r = t.getBoundingClientRect(); t.style.setProperty('--mx', (e.clientX - r.left) + 'px'); t.style.setProperty('--my', (e.clientY - r.top) + 'px'); }
    }, { passive: true });
    document.documentElement.addEventListener('mouseleave', function () { m.on = false; });
  }
  resize(); start();
})();
