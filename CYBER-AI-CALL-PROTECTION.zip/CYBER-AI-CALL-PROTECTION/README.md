# CYBER AI – Detect Smart. Stay Alert. Stay Protected.

## Dashboard
The Dashboard page shows four stat cards, the Live Security Statistics chart and the Threat Activity Map (code: `dashboard.js`).
- Total Scans, Threats Detected (Medium + High results) and the chart come from your real scan history (saved in this browser).
- Security Score, Protected Users and the world map are clearly labelled DEMO DATA. They are illustrative, not real threat intelligence.

## Screenshot upload (SMS, Email and URL pages)
Each of these pages now has two tabs: **Paste text** (unchanged) and **Upload screenshot**.
- Drag and drop or browse a JPG, PNG or WEBP image (max 10 MB). A preview and a Remove button are shown.
- The text is read with **Tesseract.js** (open-source OCR) inside your browser. QR codes in URL screenshots are decoded with **jsQR** (open-source).
- Nothing is uploaded or stored: the image never leaves your device. Only the extracted text, which you can edit, goes through the normal analysis (your AI model if connected, otherwise the built-in rules).
- Email: sender, subject and body are filled in automatically, and web addresses found are listed as plain text.
- URL: if several web addresses (or a QR code) are found, you pick which one to analyse. Links are shown as text and are never opened.
- The first time you use it, the reading tools download (about 10 MB) and the browser keeps them. You need internet for that first time.
- The result shows how clearly the text was read, separately from the scam analysis, and says it is not a security verification.
- Code: `screenshot.js`. Models are not installed by you: Tesseract.js and jsQR load from the jsDelivr CDN. To use a vision model through Ollama later (`ollama pull qwen2.5vl:7b`), the existing `/api/analyze/image` endpoint already supports it.

## Deepfake Detection (open-source models)
The Deepfake Detection page runs open-source detectors inside the browser using Transformers.js (no server, no API key):
- `onnx-community/CommunityForensics-DeepfakeDet-ViT-ONNX` (MIT license): a ViT trained to spot AI-generated images from thousands of generators.
- `prithivMLmods/Deep-Fake-Detector-v2-Model-ONNX` (Apache-2.0): a ViT classifier for "Realism" vs "Deepfake" (mainly faces).
Both are tried and their scores are averaged. If one cannot load, the other is used. Change the list in `config.js` (`window.DEEPFAKE_MODELS`).
- The first scan needs internet: the library and model files download once (tens of MB), then the browser caches them.
- Results are estimates, not proof. They can be wrong for new AI generators, screenshots and compressed images. Upload the original file when possible.
- The CommunityForensics model outputs one score, which the app treats as "higher = more likely fake".

## Call Protection (new)
Menu: **Call Protection**. Code: `callprotect.js` (page), `callintel.js` (shared logic), `netlify/functions/api.js` + `store.js` (backend), `data/verified-callers.json`, `android-app/` (Kotlin companion app).

**What is real and working (tested in a browser and with `npm test`)**
- Consent screen: nothing is enabled until the user agrees. Three optional switches (caller identification, spam-risk checking, share anonymised reports), all off by default. "Disable Protection" removes every consent; "Delete caller history" wipes the saved list.
- Manual number checker: works with no server (on-device pattern check). With consent and a server it also does the verified-list lookup and the user-report lookup. The server refuses lookups and reports that do not carry the matching consent flag.
- Results keep three kinds of evidence apart: **Verified** (only numbers in `data/verified-callers.json`), **User-submitted reports** (unverified counts, one report per reporter per number) and **Automated estimate** (rules, plus an optional AI note that is shown separately and never sees the phone number). Nothing labels a person a criminal.
- Community reports store only a salted one-way hash of the number. Set `REPORT_SALT` in `.env`. Local server saves to `data/reports.json`; on Netlify they stay in memory only, so use a hosted database for a real launch.
- Call Transcript Analysis: now also accepts transcript files (.txt .md .srt .vtt .csv .log) and shows four red-flag checks (impersonation, OTP/password/remote-access requests, payment demands, urgency/pressure) with the exact phrases found. Works with or without the AI model. Live audio transcription is NOT included, and CYBER AI never records calls.
- API (also used by the Android app): `POST /api/caller/check` and `POST /api/caller/report`. Verified list: edit `data/verified-callers.json` (add only numbers you confirmed from official sources).

**What is NOT verified**
- The Android app (`android-app/`) has not been compiled or run on a real phone. Follow its README checklist before claiming live call detection works.
- A website can never see SIM calls; only the Android app can, through Android's own permission dialog.
- The "verified list" is tiny (official helplines). Real caller-name databases and large spam datasets need a licensed data source you must add yourself.

## 0. Quickest way to see it (no install)
Double-click `index.html`. It opens in Chrome in Basic mode (built-in rule checks, clearly labelled, no AI).
In VS Code, open this folder and use Live Server on `index.html`.
Basic mode covers SMS, URL, email and call checks. Image analysis needs the AI model.

Backend: `netlify/functions/api.js` (runs on Netlify, or locally through `server.js`). It uses any
OpenAI-compatible endpoint, so you can use Ollama on your laptop or a hosted open-weight model when live.

## A. Run on your laptop (Windows 11, VS Code)
1. Install Node.js 18+ from nodejs.org and Ollama from ollama.com.
2. In a terminal: `ollama pull qwen2.5:7b-instruct` and `ollama pull qwen2.5vl:7b` (image model).
3. Open this folder in VS Code, open the terminal and run: `npm install`
4. Copy `.env.example` to `.env` (the defaults already point to Ollama).
5. `npm start`, then open http://localhost:3000
6. Optional self-test (no AI needed, 30 checks including Call Protection): `npm test`

The green box at the bottom-left shows "AI online" when the model is reachable.

## B. Go live on Netlify (this is what makes the live site work)
Ollama cannot run on Netlify, so use a hosted open-weight model (for example Groq, Together or OpenRouter).
1. Create an account with the provider and get an API key.
2. Push this folder to GitHub, then in Netlify choose "Add new site > Import from Git".
   (Settings are read from `netlify.toml`: publish `.`, functions `netlify/functions`.)
3. In Netlify > Site configuration > Environment variables, add:
   `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`, `LLM_VISION_MODEL` (see `.env.example`, Option 2).
   Check the provider's model list for current model names.
4. Trigger a new deploy. Open the site: the status box should say "AI online".

Never put the API key in frontend files. It only lives in Netlify environment variables.

## Troubleshooting
- "AI not configured": the env variables are missing. Add them and redeploy / restart.
- "Cannot reach the server": locally, run `npm start`; opened as a file, the page cannot reach the API.
- AI error 401/404: wrong key or model name. Ollama: run `ollama list` to see exact names.
- Image tool fails: your vision model name is wrong or not downloaded.

## Limits you should know
- History is stored in your browser (localStorage), not a database. Serverless functions have no permanent disk.
- No login/registration yet. Add a hosted database (Supabase or Neon Postgres) for real accounts and shared history.
- Rate limiting is basic and per function instance.
- AI results are estimates. Image detection is especially uncertain. A low score never means "safe".
