// Self-test with a fake OpenAI-compatible server. Run: npm test
const http = require('http');
const mock = http.createServer((req, res) => {
  let b = ''; req.on('data', d => b += d); req.on('end', () => {
    const bad = b.includes('BADJSON');
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ choices: [{ message: { content: bad ? 'not json' : '{"risk_score":88,"verdict":"Potential Scam","reasons":["Urgent payment"],"recommendations":["Do not click"],"confidence":0.9}' } }] }));
  });
}).listen(0, async () => {
  process.env.LLM_BASE_URL = 'http://localhost:' + mock.address().port; process.env.LLM_MODEL = 'm'; process.env.LLM_VISION_MODEL = 'v';
  const { handler } = require('./netlify/functions/api.js');
  const call = async (r, body, method = 'POST') => { const o = await handler({ path: '/api/' + r, httpMethod: method, headers: {}, body: JSON.stringify(body) }); return [o.statusCode, JSON.parse(o.body)]; };
  let fail = 0; const t = (n, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + n); if (!ok) fail++; };
  t('health', (await call('health', null, 'GET'))[1].llmConfigured);
  let [s, d] = await call('analyze/sms', { text: 'Pay now' }); t('sms ok + High', s === 200 && d.risk_level === 'High' && d.source === 'llm');
  [s] = await call('analyze/sms', { text: '' }); t('empty sms rejected', s === 400);
  [s, d] = await call('analyze/url', { url: 'http://192.168.1.1/login' }); t('url signals', s === 200 && d.signals.length >= 2);
  [s] = await call('analyze/url', { url: 'not a url' }); t('bad url rejected', s === 400);
  [s] = await call('analyze/email', { sender: 'a@b.c', subject: 's', text: 'hello' }); t('email ok', s === 200);
  [s] = await call('analyze/call', { text: 'hello caller' }); t('call ok', s === 200);
  [s] = await call('analyze/image', { mediaType: 'image/gif', image: 'x' }); t('bad image type rejected', s === 400);
  [s] = await call('analyze/image', { mediaType: 'image/png', image: 'aGk=' }); t('image ok', s === 200);
  [s] = await call('analyze/sms', { text: 'BADJSON' }); t('bad AI JSON -> error, not fake result', s === 502);
  process.env.LLM_BASE_URL = ''; [s] = await call('analyze/sms', { text: 'x' }); t('no model -> 503', s === 503);

  // ---- Call Protection: pure logic ----
  const CI = require('./callintel.js');
  t('number: +91 mobile', CI.normalizeNumber('+91 90311 82746').e164 === '+919031182746');
  t('number: 10-digit becomes +91', CI.normalizeNumber('9031182746').e164 === '+919031182746');
  t('number: letters rejected', !CI.normalizeNumber('98ab').valid);
  t('number: mask keeps last 4 only', CI.maskNumber(CI.normalizeNumber('+919031182746')).endsWith('2746') && !CI.maskNumber(CI.normalizeNumber('+919031182746')).includes('9031'));
  t('transcript: 4 red flags found', CI.transcriptFindings('This is the police. Share the OTP now or you will be arrested. Pay the fine by UPI.').filter(f => f.hit).length === 4);
  t('transcript: harmless text has none', CI.transcriptFindings('Hi, are we still meeting for lunch tomorrow?').every(f => !f.hit));
  const lowA = CI.assess(CI.normalizeNumber('9031182746'), null, { reports: 0, categories: {} });
  t('assess: clean number is Low and says it is not proof of safety', lowA.risk_level === 'Low' && /does not mean/.test(lowA.reasons[0].text));
  t('assess: many reports -> High', CI.assess(CI.normalizeNumber('9031182746'), null, { reports: 10, categories: { payment_demand: 10 } }).risk_level === 'High');

  // ---- Call Protection: API ----
  process.env.LLM_BASE_URL = 'http://localhost:' + mock.address().port; process.env.REPORT_STORE_FILE = '';
  const st = require('./netlify/functions/store.js'); st._reset();
  [s, d] = await call('caller/check', { number: '+919031182746' }); t('caller check without consent -> 400', s === 400);
  [s, d] = await call('caller/check', { number: 'abc', spam: true }); t('caller check bad number -> 400', s === 400);
  [s, d] = await call('caller/check', { number: '1930', identify: true }); t('verified official number is labelled verified', s === 200 && d.verified && /Cyber Crime/.test(d.verified.name) && d.risk_level === 'Low' && d.community.checked === false);
  [s, d] = await call('caller/check', { number: '+919031182746', spam: true }); t('unknown number: no verified identity, no accusation', s === 200 && d.verified === null && d.community.reports === 0 && d.risk_level === 'Low' && d.ai === null);
  [s] = await call('caller/report', { number: '+919031182746', category: 'payment_demand' }); t('report without consent -> 400', s === 400);
  [s] = await call('caller/report', { number: '+919031182746', category: 'nonsense', consent: true }); t('report bad category -> 400', s === 400);
  [s, d] = await call('caller/report', { number: '+919031182746', category: 'payment_demand', consent: true }); t('report accepted', s === 200 && d.added && d.reports === 1);
  [s, d] = await call('caller/report', { number: '+919031182746', category: 'payment_demand', consent: true }); t('same reporter cannot inflate count', s === 200 && !d.added && d.reports === 1);
  for (const who of ['1.1.1.1', '2.2.2.2', '3.3.3.3', '4.4.4.4']) await handler({ path: '/api/caller/report', httpMethod: 'POST', headers: { 'x-forwarded-for': who }, body: JSON.stringify({ number: '+919031182746', category: 'impersonation', consent: true }) });
  [s, d] = await call('caller/check', { number: '09031182746', spam: true }); t('5 reports -> Medium, user-reports source, AI estimate labelled separately', s === 200 && d.community.reports === 5 && d.risk_level === 'Medium' && d.reasons.some(r => r.source === 'community') && d.ai && d.ai.label === 'AI-generated estimate');
  t('reports store holds no raw number', !JSON.stringify(require('./netlify/functions/store.js').getReports('+919031182746')).includes('9031182746'));
  [s, d] = await call('analyze/call', { text: 'This is the police. Share the OTP now or be arrested. Pay the fine by UPI.' }); t('call transcript returns red-flag findings', s === 200 && d.findings.filter(f => f.hit).length === 4);
  mock.close(); process.exit(fail ? 1 : 0);
});
