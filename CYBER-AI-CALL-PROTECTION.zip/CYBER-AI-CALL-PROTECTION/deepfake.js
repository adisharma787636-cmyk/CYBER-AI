// Deepfake Detection: runs open-source detector models in the browser (Transformers.js + ONNX).
// No server and no API key are needed. Models download once from huggingface.co and are cached by the browser.
(function () {
  const LIB = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.7.3';
  // Edit the list in config.js (window.DEEPFAKE_MODELS) to change models.
  const MODELS = (window.DEEPFAKE_MODELS && window.DEEPFAKE_MODELS.length) ? window.DEEPFAKE_MODELS : [
    { id: 'onnx-community/CommunityForensics-DeepfakeDet-ViT-ONNX', name: 'CommunityForensics ViT' },
    { id: 'prithivMLmods/Deep-Fake-Detector-v2-Model-ONNX', name: 'Deep-Fake-Detector v2' }
  ];
  const FAKE = /fake|synthetic|generated|\bai\b|artificial/i, REAL = /real|authentic|natural/i;
  let lib = null; const loaded = {}, failed = {};

  async function loadModel(m, say) {
    if (loaded[m.id]) return loaded[m.id];
    if (failed[m.id]) throw failed[m.id];
    try {
      lib = lib || await import(LIB);
      lib.env.allowLocalModels = false;
      const cb = p => { if (p && p.status === 'progress' && isFinite(p.progress)) say('Downloading ' + m.name + '… ' + Math.round(p.progress) + '%'); };
      let lastErr;
      for (const dtype of ['q8', 'fp32']) {
        try {
          const processor = await lib.AutoProcessor.from_pretrained(m.id, { progress_callback: cb });
          const model = await lib.AutoModelForImageClassification.from_pretrained(m.id, { dtype, progress_callback: cb });
          return (loaded[m.id] = { processor, model });
        } catch (e) { lastErr = e; }
      }
      throw lastErr;
    } catch (e) { failed[m.id] = e; throw e; }
  }

  // Probability (0..1) that the image is fake / AI-made.
  function fakeProb(model, data) {
    if (data.length === 1) return 1 / (1 + Math.exp(-data[0]));          // single logit: higher = fake
    const mx = Math.max(...data), ex = Array.from(data, v => Math.exp(v - mx)), sum = ex.reduce((a, b) => a + b, 0), p = ex.map(v => v / sum);
    const id2 = (model.config && model.config.id2label) || {}; let fi = -1;
    for (const k in id2) if (FAKE.test(id2[k]) && !REAL.test(id2[k])) fi = +k;
    return p[fi >= 0 ? fi : data.length - 1];                              // unlabeled: last class = fake
  }

  window.deepfakeAnalyze = async function (file, say) {
    say = say || function () {};
    if (!file) throw new Error('No image selected.');
    const res = [], errs = [];
    for (const m of MODELS) {
      try {
        say('Loading ' + m.name + '…');
        const { processor, model } = await loadModel(m, say);
        say('Analyzing image…');
        const inputs = await processor(await lib.RawImage.fromBlob(file));
        const out = await model(inputs);
        res.push({ name: m.name, p: fakeProb(model, out.logits.data) });
      } catch (e) { errs.push(m.name + ': ' + (e && e.message ? e.message : e)); }
    }
    if (!res.length) throw new Error(errs.join(' | ') || 'no model could be loaded');
    const p = res.reduce((a, r) => a + r.p, 0) / res.length, spread = Math.max(...res.map(r => r.p)) - Math.min(...res.map(r => r.p));
    const disagree = res.length > 1 && spread > 0.5, score = Math.round(p * 100);
    const level = score >= 70 ? 'High' : score >= 35 ? 'Medium' : 'Low';
    const verdict = disagree ? 'Inconclusive (models disagree)' : score >= 70 ? 'Likely AI-generated or manipulated' : score >= 35 ? 'Inconclusive' : 'Likely real';
    const reasons = res.map(r => r.name + ': ' + Math.round(r.p * 100) + '% chance the image is fake or AI-made');
    reasons.push(score >= 70 ? 'The detector found patterns typical of AI-generated or edited images.' : score >= 35 ? 'The signals are mixed, so the detector cannot decide.' : 'The detector found no strong signs of AI generation or editing.');
    if (disagree) reasons.push('The two detectors gave very different answers, so treat this result with extra caution.');
    if (errs.length) reasons.push('Skipped a detector that could not load: ' + errs.join('; '));
    const rec = ['Check where the image came from and who first posted it.', 'Try a reverse image search (Google Lens or TinEye) to find the original.'];
    if (score >= 35) rec.unshift('Do not trust or share this image until its source is confirmed.');
    return { type: 'image', risk_score: score, risk_level: level, verdict, reasons, recommendations: rec,
      confidence: Math.min(0.95, Math.abs(p - 0.5) * 2 * (disagree ? 0.5 : 1)), model: res.map(r => r.name).join(' + '), source: 'open-model',
      limitations: 'Open-source detectors give an estimate, not proof. They can be wrong for new AI generators, screenshots and heavily compressed images. Upload the original file when you can.' };
  };
})();
