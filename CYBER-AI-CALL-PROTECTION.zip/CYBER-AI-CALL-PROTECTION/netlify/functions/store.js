// Community report store. Raw phone numbers are NEVER saved: only a salted one-way hash of the number.
// Local server: persisted to REPORT_STORE_FILE (server.js sets data/reports.json). Netlify: in memory only
// (serverless functions have no permanent disk), so use a hosted database for a real deployment.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
let mem = null;
const file = () => process.env.REPORT_STORE_FILE || '';
const salt = () => process.env.REPORT_SALT || 'cyberai-dev-salt-please-change';
const hmac = s => crypto.createHmac('sha256', salt()).update(s).digest('hex');
const MAX_REPORTERS = 500;

function load() {
  if (mem) return mem;
  mem = {};
  if (file()) { try { mem = JSON.parse(fs.readFileSync(file(), 'utf8')) || {}; } catch { mem = {}; } }
  return mem;
}
function save() {
  if (!file()) return;
  try { fs.mkdirSync(path.dirname(file()), { recursive: true }); fs.writeFileSync(file() + '.tmp', JSON.stringify(mem)); fs.renameSync(file() + '.tmp', file()); }
  catch (e) { console.error('report store save failed:', e.message); }
}
// number key = normalised number (e.g. "+919876543210"). Returns only aggregate counts.
function getReports(numberKey) {
  const e = load()[hmac('n|' + numberKey)];
  return e ? { reports: e.r.length, categories: { ...e.c }, last: e.t } : { reports: 0, categories: {}, last: null };
}
// One report per reporter per number: the reporter is only a one-way fingerprint, never an account or an IP.
function addReport(numberKey, category, reporterId) {
  const db = load(), h = hmac('n|' + numberKey), who = hmac('r|' + reporterId + '|' + h).slice(0, 20);
  const e = db[h] || (db[h] = { r: [], c: {}, t: null });
  if (e.r.includes(who)) return { added: false, ...getReports(numberKey) };
  if (e.r.length < MAX_REPORTERS) e.r.push(who);
  e.c[category] = (e.c[category] || 0) + 1; e.t = new Date().toISOString().slice(0, 10);
  save();
  return { added: true, ...getReports(numberKey) };
}
const mode = () => (file() ? 'file' : 'memory');
const _reset = () => { mem = {}; };
module.exports = { getReports, addReport, mode, _reset };
