// Approved dashboard (cards + live chart + threat map). Loaded before app.js, which calls dashboard().
(function () {
  const LAND = [
    [[-168, 66], [-162, 70], [-141, 70], [-125, 70], [-110, 73], [-95, 72], [-82, 69], [-80, 63], [-94, 60], [-93, 57], [-82, 55], [-78, 62], [-70, 60], [-62, 58], [-56, 52], [-60, 47], [-66, 45], [-70, 42], [-76, 38], [-76, 35], [-81, 31], [-80, 26], [-82, 27], [-85, 30], [-90, 29], [-94, 29], [-97, 26], [-97, 22], [-95, 19], [-91, 18], [-87, 21], [-88, 16], [-83, 15], [-83, 10], [-79, 9], [-81, 8], [-86, 11], [-92, 14], [-97, 16], [-105, 20], [-110, 24], [-115, 30], [-117, 33], [-121, 35], [-124, 40], [-124, 47], [-128, 51], [-134, 57], [-140, 60], [-148, 60], [-153, 58], [-160, 57], [-165, 61], [-166, 64]],
    [[-55, 60], [-45, 60], [-40, 65], [-22, 70], [-20, 76], [-30, 83], [-55, 82], [-70, 78], [-58, 75], [-52, 69]],
    [[-77, 8], [-72, 12], [-62, 11], [-52, 5], [-50, 0], [-44, -2], [-35, -5], [-35, -9], [-39, -15], [-41, -22], [-48, -26], [-53, -34], [-58, -38], [-63, -41], [-65, -45], [-68, -50], [-69, -54], [-74, -52], [-74, -45], [-72, -35], [-71, -28], [-70, -18], [-76, -14], [-81, -6], [-80, -2], [-78, 2]],
    [[-9, 37], [-9, 43], [-2, 43.5], [-4.5, 48], [2, 51], [8, 54], [9, 57], [12, 55], [20, 55], [22, 60], [30, 60], [24, 66], [18, 69], [26, 71], [40, 68], [44, 68], [60, 69], [70, 73], [80, 73], [100, 77], [113, 74], [130, 71], [140, 72], [160, 70], [170, 70], [180, 68], [180, 65], [170, 60], [163, 58], [160, 53], [156, 57], [143, 59], [135, 55], [141, 52], [140, 46], [130, 42], [129, 35], [126, 38], [122, 40], [121, 32], [120, 26], [110, 21], [107, 17], [109, 12], [105, 9], [100, 13], [100, 8], [103, 1], [98, 8], [98, 16], [94, 17], [91, 22], [87, 21], [80, 15], [77, 8], [73, 17], [72, 21], [67, 24], [57, 25], [56, 27], [50, 30], [48, 29], [51, 25], [56, 24], [59, 22], [55, 17], [44, 13], [39, 21], [35, 28], [34, 31], [36, 36], [27, 37], [26, 40], [23, 36], [20, 40], [19, 42], [14, 45], [18, 40], [16, 38], [12, 42], [9, 44], [3, 43], [-1, 37], [-5, 36]],
    [[-17, 21], [-16, 28], [-10, 31], [-6, 36], [10, 37], [11, 33], [20, 31], [32, 31], [34, 28], [38, 20], [43, 12], [51, 12], [47, 5], [41, -2], [40, -10], [40, -15], [35, -24], [32, -29], [27, -34], [20, -35], [18, -32], [15, -26], [12, -17], [13, -8], [9, -1], [9, 4], [4, 6], [-4, 5], [-8, 4], [-13, 8], [-17, 14]],
    [[114, -22], [122, -18], [130, -12], [137, -12], [142, -11], [145, -15], [153, -26], [150, -37], [141, -38], [135, -35], [131, -31], [115, -34]],
    [[-5, 50], [1, 51], [2, 53], [-2, 57], [-5, 58], [-6, 55], [-3, 54]],
    [[130, 31], [135, 34], [140, 36], [142, 40], [140, 42], [137, 37], [131, 34]],
    [[109, 1], [117, 7], [119, 1], [116, -4], [110, -3]], [[172, -34], [178, -38], [174, -41]], [[172, -41], [174, -42], [170, -46], [167, -46]], [[44, -25], [48, -14], [50, -15], [47, -25]], [[95, 5], [106, -6], [104, -6], [98, 0]]];
  const X = lon => (lon + 180) / 360 * 1000, Y = lat => (90 - lat) / 180 * 500;
  const MK = [['North America', -100, 40, '#FFB547', 'Medium'], ['Europe', 10, 51, '#356BFF', 'Low'], ['Africa', 20, 5, '#FF526B', 'High'], ['South America', -55, -12, '#00D9FF', 'Low'], ['Oceania', 140, -28, '#8a5cff', 'Medium'], ['Asia', 85, 30, '#FF526B', 'High'], ['Southeast Asia', 108, 12, '#FFB547', 'Medium'], ['Middle East', 46, 28, '#356BFF', 'Low']];
  
  const dayKey = d => d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  function series(days) {
    const rows = [];
    for (let i = days - 1; i >= 0; i--) { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i); rows.push({ key: dayKey(d), Low: 0, Medium: 0, High: 0 }); }
    getH().forEach(x => { const r = rows.find(y => y.key === dayKey(new Date(x.at))); if (r && r[x.level] !== undefined) r[x.level]++; });
    return rows;
  }
  const sparkSvg = v => { const mx = Math.max(...v), mn = Math.min(...v), pts = v.map((y, i) => [i / (v.length - 1) * 200, 46 - (mx === mn ? 0 : (y - mn) / (mx - mn)) * 38]); let d = 'M' + pts[0].map(n => n.toFixed(1)).join(','); for (let i = 1; i < pts.length; i++) d += ' L' + pts[i].map(n => n.toFixed(1)).join(','); return `<svg class="spark" viewBox="0 0 200 54" preserveAspectRatio="none" aria-hidden="true"><path d="${d}" fill="none" stroke="#356BFF" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>`; };

  // ---- real data grouped by the chosen time range ----
  function rangeData(key) {
    const now = new Date(), H = getH().map(x => ({ t: new Date(x.at), lv: x.level })), defs = [];
    const DN = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    if (key === 'week' || key === 'last') {
      const mon = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7) - (key === 'last' ? 7 : 0));
      for (let i = 0; i < 7; i++) defs.push([DN[i], new Date(mon.getFullYear(), mon.getMonth(), mon.getDate() + i), new Date(mon.getFullYear(), mon.getMonth(), mon.getDate() + i + 1)]);
    } else if (key === 'month') {
      const y = now.getFullYear(), m = now.getMonth(), dim = new Date(y, m + 1, 0).getDate();
      for (let w = 0; w < Math.ceil(dim / 7); w++) defs.push(['Week ' + (w + 1), new Date(y, m, w * 7 + 1), new Date(y, m, Math.min(dim, w * 7 + 7) + 1)]);
    } else for (let m = 0; m < 12; m++) defs.push([MN[m], new Date(now.getFullYear(), m, 1), new Date(now.getFullYear(), m + 1, 1)]);
    const out = { l: [], safe: [], sus: [], hi: [] };
    defs.forEach(([l, s, e]) => { const inR = H.filter(x => x.t >= s && x.t < e); out.l.push(l); out.safe.push(inR.filter(x => x.lv === 'Low').length); out.sus.push(inR.filter(x => x.lv === 'Medium').length); out.hi.push(inR.filter(x => x.lv === 'High').length); });
    return out;
  }
  function niceTop(mx) { if (mx <= 4) return 4; const raw = mx / 4, p = Math.pow(10, Math.floor(Math.log10(raw))); const step = [1, 2, 2.5, 5, 10].map(f => f * p).find(s => s >= raw); return Math.round(step * 4); }
  function drawChart(key) {
    const d = rangeData(key), mx = Math.max(0, ...d.safe, ...d.sus, ...d.hi), top = niceTop(mx), pos = [0, 1, 2, 3, 4], none = mx === 0;
    $('#chart').innerHTML = `<div class="plot"><div class="yaxis">${pos.map(i => `<span style="bottom:${i * 25}%">${Math.round(top * i / 4)}</span>`).join('')}</div>
     <div class="area">${pos.map(i => `<div class="gl" style="bottom:${i * 25}%"></div>`).join('')}
     <div class="cols">${d.l.map((x, i) => `<div class="col" data-tip="${esc(x)}|${d.safe[i]}|${d.sus[i]}|${d.hi[i]}"><div class="bars">${[['safe', d.safe], ['sus', d.sus], ['hi', d.hi]].map(([c, a], j) => `<i class="b ${c}" data-h="${a[i] / top * 100}" data-v="${a[i]}" style="transition-delay:${i * 50 + j * 40}ms"></i>`).join('')}</div><span>${esc(x)}</span></div>`).join('')}</div>
     ${none ? '<div class="nodata">No scans in this period yet. Run a scan to see live activity here.</div>' : ''}<div class="tip" id="tip" hidden></div></div></div>
     <div class="legend"><span><i class="dot safe"></i>Safe</span><span><i class="dot sus"></i>Suspicious</span><span><i class="dot hi"></i>High-risk</span></div>`;
    requestAnimationFrame(() => requestAnimationFrame(() => document.querySelectorAll('#chart .b').forEach(b => { b.style.height = b.dataset.h + '%'; b.style.minHeight = +b.dataset.v ? '4px' : '0'; })));
    const cols = $('#chart .cols'), tip = $('#tip');
    cols.addEventListener('mouseover', e => { const c = e.target.closest('.col'); if (!c) return; const [x, a, b, h] = c.dataset.tip.split('|');
      tip.innerHTML = `<b>${x}</b><div><i class="dot safe"></i>Safe: ${a}</div><div><i class="dot sus"></i>Suspicious: ${b}</div><div><i class="dot hi"></i>High-risk: ${h}</div>`;
      tip.style.left = Math.min(Math.max(c.offsetLeft + c.offsetWidth / 2, 75), cols.offsetWidth - 75) + 'px'; tip.hidden = false; });
    cols.addEventListener('mouseleave', () => { tip.hidden = true; });
  }

  function drawMap() {
    $('#map').innerHTML = LAND.map(p => `<path class="land" d="M${p.map(([a, b]) => X(a).toFixed(1) + ',' + Y(b).toFixed(1)).join(' L')}Z"/>`).join('') +
      MK.map(([n, lo, la, c, lv], i) => `<g class="mk" style="color:${c}" data-i="${i}" tabindex="0" role="img" aria-label="${n}, demo activity ${lv}"><circle class="ring" cx="${X(lo)}" cy="${Y(la)}" r="9" style="animation-delay:${i * .3}s"/><circle class="core" cx="${X(lo)}" cy="${Y(la)}" r="6" fill="currentColor"/></g>`).join('');
    const mb = $('#mapbox'), mt = $('#mtip');
    const show = g => { const [n, , , , lv] = MK[+g.dataset.i]; mt.innerHTML = `<b>${n}</b><div>Demo activity level: ${lv}</div><div style="color:#ffcf8a">Illustrative demo data, not real</div>`;
      const r = g.getBoundingClientRect(), b = mb.getBoundingClientRect(); mt.style.left = Math.min(Math.max(r.left + r.width / 2 - b.left, 120), b.width - 120) + 'px'; mt.style.top = (r.top - b.top) + 'px'; mt.hidden = false; };
    document.querySelectorAll('.mk').forEach(g => { g.addEventListener('mouseenter', () => show(g)); g.addEventListener('focus', () => show(g)); g.addEventListener('mouseleave', () => { mt.hidden = true; }); g.addEventListener('blur', () => { mt.hidden = true; }); });
  }

  function dashboard() {
    const h = getH(), s7 = series(7), threats = h.filter(x => x.level !== 'Low').length;
    const I = {
      scan: '<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3"/>',
      alert: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M12 8v4M12 16h.01"/>',
      check: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
      users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20a7 7 0 0 1 14 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 20a7 7 0 0 0-3-5.7"/>' };
    // real: Total Scans, Threats Detected. demo (no real source): Security Score, Protected Users
    const K = [['Total Scans', h.length, '', I.scan, s7.map(r => r.Low + r.Medium + r.High), false],
      ['Threats Detected', threats, '', I.alert, s7.map(r => r.Medium + r.High), false],
      ['Security Score', 97, '%', I.check, [14, 22, 20, 30, 24, 32, 28, 34], true],
      ['Protected Users', 1234, '', I.users, [18, 26, 22, 32, 24, 34, 29, 24], true]];
    $('#main').innerHTML = `<h1>Dashboard</h1><p class="sub">Your analysis activity on this device.</p>
    <div class="dash"><div class="kpis">${K.map(([l, n, suf, i, s, demo]) => `<div class="card kpi"><div class="kico">${ico(i)}</div><div><b><span class="cnt" data-n="${n}" data-s="${suf}">0${suf}</span>${demo ? '<span class="demo">DEMO</span>' : ''}</b><span class="l">${l}</span></div>${sparkSvg(s)}</div>`).join('')}</div>
    <div class="right">
      <section class="card"><div class="chead"><h3>Live Security Statistics <span class="demo live">YOUR SCANS</span></h3><select id="range" aria-label="Time range"><option value="week">This Week</option><option value="last">Last Week</option><option value="month">This Month</option><option value="year">This Year</option></select></div><div id="chart"></div></section>
      <section class="card"><div class="chead"><h3>Threat Activity Map <span class="demo">DEMO DATA – illustrative, not real threat intelligence</span></h3></div><div class="mapbox" id="mapbox"><svg id="map" viewBox="0 40 1000 370" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Illustrative world map with demo markers"></svg><div class="mtip" id="mtip" hidden></div></div></section>
    </div></div>
    <div class="grid"><div class="card"><h3>Recent analyses</h3>${h.length ? h.slice(0, 5).map(x => `<div class="bar"><span class="lvl ${x.level}" style="width:70px">${x.level}</span><span>${esc(MODS[x.type].name.split(' ')[0])}: ${esc(x.preview.slice(0, 36))}</span></div>`).join('') : '<div class="empty">No analyses yet. Pick a tool to start.</div>'}</div>
    <div class="card"><h3>Start an analysis</h3><div class="tools">${Object.entries(MODS).map(([k, m]) => `<a class="tool" href="#${k}"><b>${esc(m.name)}</b><small>${esc(m.short)}</small></a>`).join('')}</div></div></div>
    <div class="card"><h3>Stay safe</h3><ul><li>No bank, police or government office will ask for your OTP, PIN or password.</li><li>Do not click links in unexpected messages. Open the official app or type the website yourself.</li><li>Scammers create panic. Stop, breathe, and call the organization on its official number.</li><li>Never install apps or share your screen because a caller asked you to.</li></ul></div>`;
    document.querySelectorAll('.cnt').forEach(el => {
      const n = +el.dataset.n, s = el.dataset.s, fmt = v => Math.round(v).toLocaleString('en-US') + s;
      if (matchMedia('(prefers-reduced-motion: reduce)').matches || !n) { el.textContent = fmt(n); return; }
      const t0 = performance.now(); (function f(t) { const p = Math.min(1, (t - t0) / 1000); el.textContent = fmt(n * (1 - Math.pow(1 - p, 3))); if (p < 1 && document.body.contains(el)) requestAnimationFrame(f); })(t0);
    });
    drawChart('week'); drawMap(); $('#range').onchange = e => drawChart(e.target.value);
  }
  window.dashboard = dashboard;
})();
