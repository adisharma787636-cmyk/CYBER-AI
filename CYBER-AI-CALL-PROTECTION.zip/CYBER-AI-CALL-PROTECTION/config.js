// Leave empty when the site and API are on the same domain (Netlify + functions).
// If your API is hosted elsewhere, set e.g. window.API_BASE = "https://your-api.example.com";
window.API_BASE = "";

// Deepfake Detection models (open-source, run in the browser). Remove the "//" to override the defaults.
// window.DEEPFAKE_MODELS = [
//   { id: "onnx-community/CommunityForensics-DeepfakeDet-ViT-ONNX", name: "CommunityForensics ViT" },
//   { id: "prithivMLmods/Deep-Fake-Detector-v2-Model-ONNX", name: "Deep-Fake-Detector v2" }
// ];
